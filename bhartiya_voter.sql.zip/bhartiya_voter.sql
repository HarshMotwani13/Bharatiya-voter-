--
-- Database: `bhartiya_voter`
--

-- --------------------------------------------------------

--
-- Table structure for table `adlog`
--

CREATE TABLE `adlog` (
  `email` varchar(20) NOT NULL,
  `pass` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `adlog`
--

INSERT INTO `adlog` (`email`, `pass`) VALUES
('divesh@bv.in', 'tester'),
('harsh@bv.in', 'tester'),
('rahul@bv.in', 'tester'),
('shaikh44@bv.in', 'tester');

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `name` varchar(20) NOT NULL,
  `email` varchar(50) NOT NULL,
  `comment` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`name`, `email`, `comment`) VALUES
('Danish Shaikh', 'shaikh.danish4444@gmail.com', 'dsad');

-- --------------------------------------------------------

--
-- Table structure for table `rgst`
--

CREATE TABLE `rgst` (
  `count` bigint(20) NOT NULL,
  `FName` varchar(20) NOT NULL,
  `MName` varchar(20) NOT NULL,
  `LName` varchar(20) NOT NULL,
  `bday` date NOT NULL,
  `gender` varchar(6) NOT NULL,
  `UID` bigint(12) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `rgst`
--

INSERT INTO `rgst` (`count`, `FName`, `MName`, `LName`, `bday`, `gender`, `UID`) VALUES
(1, 'Danish', '', 'Shaikh', '1999-01-04', 'Male', 12345678901);

-- --------------------------------------------------------

--
-- Table structure for table `test`
--

CREATE TABLE `test` (
  `FULL_NAME` varchar(50) NOT NULL,
  `UID` bigint(12) NOT NULL,
  `PAN` varchar(10) NOT NULL,
  `gender` varchar(6) NOT NULL,
  `bday` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `test`
--

INSERT INTO `test` (`FULL_NAME`, `UID`, `PAN`, `gender`, `bday`) VALUES
('Danish Shaikh', 123456789012, 'AAAPL1234C', 'Male', '1999-01-04'),
('Azhar Shaikh', 123456789013, 'AAAPL1234D', 'Male', '1995-03-23'),
('Harsh Motwani', 123456789014, 'AAAPL1234E', 'Male', '1998-11-11'),
('Divesh Kukruja', 123456789015, 'AAAPL1234F', 'Male', '1999-12-31'),
('Anmol Ranglani', 123456789016, 'AAAPL1234G', 'Male', '1998-02-03'),
('Rahul Bhadra', 123456789017, 'AAAPL1234H', 'Male', '1999-12-31'),
('Somesh hinduja', 123456789022, 'AAAPL12340', 'Male', '1999-12-31');

-- --------------------------------------------------------

--
-- Table structure for table `vefi`
--

CREATE TABLE `vefi` (
  `Email` varchar(32) NOT NULL,
  `PNumber` bigint(10) NOT NULL,
  `UID` bigint(12) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `vefi`
--

INSERT INTO `vefi` (`Email`, `PNumber`, `UID`) VALUES
('', 8655332519, 12345678901);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `adlog`
--
ALTER TABLE `adlog`
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `feedback`
--
ALTER TABLE `feedback`
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `rgst`
--
ALTER TABLE `rgst`
  ADD PRIMARY KEY (`count`),
  ADD UNIQUE KEY `UID` (`UID`);

--
-- Indexes for table `test`
--
ALTER TABLE `test`
  ADD UNIQUE KEY `UID` (`UID`);

--
-- Indexes for table `vefi`
--
ALTER TABLE `vefi`
  ADD UNIQUE KEY `UID` (`UID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `rgst`
--
ALTER TABLE `rgst`
  MODIFY `count` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

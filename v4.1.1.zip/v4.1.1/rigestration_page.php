<?php//Session starts here
session_start();?>

<html>
	<head>
		<title>BHARTIYA VOTER</title>

		<!-- browser info -->
		<meta charset="UTF-8">
		<meta name="description" content="Free Web tutorials">
		<meta name="keywords" content="HTML,CSS,XML,JavaScript">
		<meta name="author" content="DANISH SHAIKH">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">

		<link href="assets/css/bootstrap.css" rel="stylesheet">

		<!-- core bootstrap -->
		<link rel="stylesheet" href="assets/css/bootstrap.min.css">
		<link rel="stylesheet" href="assets/css/w3.css">
		<!-- Custom style -->
		<link href="assets/css/mystyle.css" rel="stylesheet">
	</head>

	<style>
			body {background: url(assets/img/c-slide-3.jpg) no-repeat fixed 100% 100%;background-size:100% 100%;background-position:center;}

			input[type=text], select {width: 100%;padding: 12px 20px;margin: 8px 0;display: inline-block;border: 1px solid #ccc;border-radius: 4px;box-sizing: border-box;}

			input[type=number], select {width: 100%;padding: 12px 20px;margin: 8px 0;display: inline-block;border: 1px solid #ccc;border-radius: 4px;box-sizing: border-box;}

			input[type=email], select {width: 100%;padding: 12px 20px;margin: 8px 0;display: inline-block;border: 1px solid #ccc;border-radius: 4px;box-sizing: border-box;}

			input[type=date], select {width: 100%;padding: 12px 20px;margin: 8px 0;display: inline-block;border: 1px solid #ccc;border-radius: 4px;box-sizing: border-box;}


			input[type=submit] {width: 100%;background-color: #4CAF50;color: white;padding: 14px 20px;margin: 8px 0;border: none;border-radius: 4px;cursor: pointer;}
			input[type=submit]:hover {background-color: #45a049;}

			.inp{width: 100%;background-color: #4CAF50;color: white;padding: 14px 20px;margin: 8px 0;border: none;border-radius: 4px;cursor: pointer;}
			.inp:hover {background-color: #45a049;}

			.box {border-radius: 5px;background-color: #f2f2f2;padding: 20px;}

			.btn-2 { background:orange;}
			.btn-2:hover { backgroung:green;}
	</style>

	<body>

		<!--------- TITLE BAR --------->
		<button class="inp" style="margin:0px;font-size:20px;"  onclick="location.href='index.php'"><span class="glyphicon glyphicon-home" style="color:white;">&nbsp;</span>HOME</button>
		<div  class="jumbotron text-center" style="margin:0px;background-color:rgba(0,0,0, 0.7);color:white;">
		<h1>REGISTRATION</h1>
		</div>
		<!--------- TITLE BAR End--------->

		<!--------- MAIN PAGE --------->
		<form action="verification_page.php" method="post">
			<div  id="" style="padding:3%; box-shadow: 0px 0px 15px black inset;  ">
				<div id="main" class="" >
				<span id="error">
				<!----Initializing Session for errors--->
                    <?php
                    if (!empty($_SESSION['error'])) {
                        echo $_SESSION['error'];
                        unset($_SESSION['error']);
                    }

                    ?>
                </span>
					<div class="container box" style="opacity:0.9">
						<div class="w3-container col-sm-6" style=" height:;">
						  <div class="w3-card-8 w3-dark-grey" style="height:100%;padding:20px;">
							<div class="w3-container w3-center" style="background-color:white;padding:20px;height:100%;border-radius:20px;" >
							  <img src="assets/img/logo.png" height="100%" width="100%" alt="Avatar" style="">
							  <input type="file" name="filename"  accept="image/gif, image/jpeg, image/png">
							</div>
							<!-- <div class="w3-section">
								<button class="w3-btn w3-green">Accept</button>
								<button class="w3-btn w3-red">Decline</button>
							  </div>-->
						  </div>
						</div>



						<div class="col-sm-6">
						<div class="col-sm-" ><b style="font-size:30px;">Enter The Name:</b></div>
							<div class="col-sm-"><input type="text"  name="FName" placeholder="Enter First Name" required></div>
							<div class="col-sm-"><input type="text"  name="MName"placeholder="Enter Middle Name"></div>
							<div class="col-sm-"><input type="text"  name="LName" placeholder="Enter Last Name" required></div>

							<div class="col-sm-">
								<b style="font-size:30px;">Select Date of Birth: </b><br>
								<input name="bday" type="text" placeholder="Birth Date" required onfocus="(this.type='date')" onblur="if(this.value==''){this.type='text'}" min="1900-01-01" max="1999-12-31" required><br>
  					</div>

							<div class="col-sm-">
								<b style="font-size:30px;">Choose Your Gender : </b>
								<select name="gender" style="" required>
									<option value="" >----Select----</option>
									<option value="Male" value="" >MALE</option>
									<option value="Female" value="">FEMALE</option>
									<option value="other" value="">Transgender</option>
								</select>
							</div>

							<div class="col-sm-">

									<b style="font-size:30px;">Document: </b> <br>


							</div>


							<div class="col-sm-"><input type="text" maxlength="12"  name="UID" placeholder="Adhar Card Number " required ></div>
              <div class="col-sm-"><input type="text" maxlength="10"  name="PAN" placeholder="PAN Card Number " required ></div>

              <div class="col-sm-">

                  <b style="font-size:30px;">Region: </b> <br>

              </div>

              <div class="col-sm-"><input type="text" maxlength="6"  name="region" placeholder="Ex : 400070" required ></div>


						</div>
						<div class="container" style="width:100%;">
							<h3><input type="submit" value="Click To Submit" style="opacity:0.8;background:orange;" class="w3-btn w3-green w3-text-shadow" ></h3>
						</div>
					</div>
				</div>
			</div>
		</form>
		<!-- ------ MAIN PAGE End --------->




	<!-- ********** CREDITS ********** -->
  <div id="" class="" data-effect="slide-bottom" style="position:0px ;background-color:white;width:100%;height:150px;padding-top:20px;box-shadow: 0px 0px 15px black inset;">
    <div class="container">
      <div class="row">
        <div class="centered text-center">
          <footer class="container-fluid text-center" >

            <p>Voting Website Designed By <b>Danish Shaikh</b> </p>
            <a href="team_page.php">Developer Team</a>
            <br><br>
            <p> Copyright <strong>@ V.E.S. Polytechnic</strong></p>
          </footer>
        </div>
      </div>
    </div><! --/container -->



	</body>
</html>

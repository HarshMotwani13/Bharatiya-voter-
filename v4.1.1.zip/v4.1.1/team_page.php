<html>
<head>
  <title>BHARTIYA VOTER</title>

  <!-- browser info -->
  <meta charset="UTF-8">
  <meta name="description" content="Free Web tutorials">
  <meta name="keywords" content="HTML,CSS,XML,JavaScript">
  <meta name="author" content="DANISH SHAIKH">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">


  <link href="assets/css/bootstrap.css" rel="stylesheet">

  <!-- core bootstrap -->
  <link rel="stylesheet" href="assets/css/bootstrap.min.css">
  <link rel="stylesheet" href="assets/css/w3.css">
  <!-- Custom style -->
  <link href="assets/css/mystyle.css" rel="stylesheet">
</head>
<style>
    body {background: url(assets/img/c-slide-3.jpg) no-repeat fixed 100% 100%;background-size:100% 100%;background-position:center;}

    .inp{width: 100%;background-color: #4CAF50;color: white;padding: 14px 20px;margin: 8px 0;border: none;border-radius: 4px;cursor: pointer;}
    .inp:hover {background-color: #45a049;}
h1 {font-size: 40px;}
</style>

<body>

  <!--------- TITLE BAR --------->
  <button class="inp" style="margin:0px;font-size:20px;"  onclick="location.href='index.php'"><span class="glyphicon glyphicon-home" style="color:white;">&nbsp;</span>HOME</button>
  <div  class="jumbotron text-center" style="margin:0px;background-color:rgba(0,0,0, 0.7);color:white;">
  <h1>DEVELOPER TEAM</h1>
  </div>
  <!--------- TITLE BAR End--------->

<div style="" class="col-sm-12">
 <div class="col-sm-12"  style="padding:50px;" >
    <div class="col-sm-3 text-center">
      <img src="assets/img/user.png" alt="harsh">
      <h1 style="color:white" class="">Harsh Motwani</h1>
      <p>Data Collector for the Bhartiya Voter</p>
      <p>Coordinator for the Bhartiya Voter</p>
      <br>
      <div style="background-color:rgba(200,200,200,0.7);padding:20px;border-radius:20px;border: solid 1px black  ">
        <strong style="color:white"><h3 style="background-color:rgba(100,100,100,0.7);padding:10px;border-radius:10px;">CONTACT DETAILS</h3></strong>
        <p>+91 9172381313</p>
        <p>harsh.d.motwani@gmail.com</p>
      </div>
    </div>

    <div class="col-sm-3 text-center">
      <img src="assets/img/user.png" alt="danish">
      <h1 style="color:white" class="">Danish Shaikh</h1>
      <p>GUI Designer for the Bhartiya Voter</p>
      <p>Writer for the Bhartiya Voter</p>
      <br>
      <div style="background-color:rgba(200,200,200,0.7);padding:20px;border-radius:20px;border: solid 1px black">
        <strong style="color:white"><h3 style="background-color:rgba(100,100,100,0.7);padding:10px;border-radius:10px;">CONTACT DETAILS</h3></strong>
        <p>+91 8655332519</p>
        <p>shaikh.danish4444@gmail.com</p>
      </div>

    </div>

    <div class="col-sm-3 text-center">
      <img src="assets/img/user.png" alt="rahul">
      <h1 style="color:white" class="">Rahul Bhadhra</h1>
      <p>Indender for the Bhartiya Voter</p>
      <p>Side Speaker for the Bhartiya Voter</p>
      <br>
      <div style="background-color:rgba(200,200,200,0.7);padding:20px;border-radius:20px;border: solid 1px black">
        <strong style="color:white"><h3 style="background-color:rgba(100,100,100,0.7);padding:10px;border-radius:10px;">CONTACT DETAILS</h3></strong>
        <p>+91 012345679</p>
        <p>address1234@gmail.com</p>
      </div>
    </div>

    <div class="col-sm-3 text-center">
      <img src="assets/img/user.png" alt="divesh">
      <h1 style="color:white" class="">Divesh Kukreja</h1>
      <p>Intender for the Bhartiya Voter</p>
      <p>Data Collector for the Bhartiya Voter</p>
      <br>
      <div style="background-color:rgba(200,200,200,0.7);padding:20px;border-radius:20px;border: solid 1px black">
        <strong style="color:white"><h3 style="background-color:rgba(100,100,100,0.7);padding:10px;border-radius:10px;">CONTACT DETAILS</h3></strong>
        <p>+91 012345679</p>
        <p>address1234@gmail.com</p>
      </div>
    </div>

</div>
</div>

<!-- ********** CREDITS ********** -->
<div id="" class="col-sm-12" data-effect="slide-bottom" style="position: ;background-color:white;width:100%;height:150px;padding-top:20px;box-shadow: 0px 0px 15px black inset;">
  <div class="container">
    <div class="row">
      <div class="centered text-center">
        <footer class="container-fluid text-center" >

          <p>Voting Website Designed By <b>Danish Shaikh</b> </p>
          <a href="team_page.php">Developer Team</a>
          <br><br>
          <p> Copyright <strong>@ V.E.S. Polytechnic</strong></p>
        </footer>
      </div>
    </div>
  </div>
</div>

</body>
</html>

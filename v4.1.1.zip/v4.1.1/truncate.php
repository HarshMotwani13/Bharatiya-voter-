<?php
$party1 = "(AITC)  All India Trinamool Congress.";
$party1_sym = "AITC";

$party2 = "(BSP)   Bhujan Samaj Party.";
$party2_sym = "BSP";

$party3 = "(BJP)   Bhartiya Janta Party.";
$party3_sym = "BJP";

$party4 = "(CPI)   Communist Party of India.";
$party4_sym = "CPI";

$party5 = "(CPI-M) Communist Party of India (Marxist).";
$party5_sym = "CPIM";

$party6 = "(INC)   Indian National Congress.";
$party6_sym = "INC";

$party7 = "(NCP)   Nationalist Congress Party.";
$party7_sym = "NCP";

$db = mysqli_connect('localhost','root','','vote_collect') or die('Error connecting to MySQL server.');
$db2 = mysqli_connect('localhost','root','','bhartiya_voter') or die('Error connecting to MySQL server.');

?>

<?php
mysqli_query($db2, "truncate table rgst") or die('Error querying database.');
mysqli_query($db2,"truncate table vefi") or die('Error querying database.');

mysqli_query($db, "truncate table aa_citizen_voted") or die('Error querying database.');

mysqli_query($db, "truncate table $party1_sym") or die('Error querying database.');

mysqli_query($db, "truncate table $party2_sym") or die('Error querying database.');

mysqli_query($db, "truncate table $party3_sym") or die('Error querying database.');

mysqli_query($db, "truncate table $party4_sym") or die('Error querying database.');

mysqli_query($db, "truncate table $party5_sym") or die('Error querying database.');

mysqli_query($db, "truncate table $party6_sym") or die('Error querying database.');

mysqli_query($db, "truncate table $party7_sym") or die('Error querying database.');

 echo "<script type='text/javascript'>alert('All Tables Are Truncated !!!');</script>";
 echo "<script type='text/javascript'>window.location='vote_check.php';</script>";
?>

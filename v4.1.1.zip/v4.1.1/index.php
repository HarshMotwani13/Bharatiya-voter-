<html lang="en">
	<head>

		<meta charset="utf-8">
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<meta name="description" content="">
		<meta name="author" content="DANISH SHAIKH">
		<link rel="icon" href="assets/img/logo.png">

		<title>BHARTIYA VOTER</title>

		<!-- Bootstrap core CSS -->
		<link href="assets/css/bootstrap.css" rel="stylesheet">

		<!-- Custom styles for this template -->
		<link href="assets/css/custom-animations.css" rel="stylesheet">
		<link href="assets/css/mystyle.css" rel="stylesheet">

		<!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
		<script src="assets/js/ie10-viewport-bug-workaround.js"></script>

		<!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
		<!--[if lt IE 9]>
			<script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
			<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
		<![endif]-->
		<script type="text/javascript">
			(function(g,h,c,j,d,l,k){/*! Jssor */
			new(function(){});var e={sd:function(a){return-c.cos(a*c.PI)/2+.5},ud:function(a){return a},Yf:function(a){return a*a},Bd:function(a){return-a*(a-2)},Ce:function(a){return(a*=2)<1?1/2*a*a:-1/2*(--a*(a-2)-1)},Ae:function(a){return a*a*a},ze:function(a){return(a-=1)*a*a+1},ye:function(a){return(a*=2)<1?1/2*a*a*a:1/2*((a-=2)*a*a+2)},xe:function(a){return a*a*a*a},Fe:function(a){return-((a-=1)*a*a*a-1)},we:function(a){return(a*=2)<1?1/2*a*a*a*a:-1/2*((a-=2)*a*a*a-2)},te:function(a){return a*a*a*a*a},qe:function(a){return(a-=1)*a*a*a*a+1},pe:function(a){return(a*=2)<1?1/2*a*a*a*a*a:1/2*((a-=2)*a*a*a*a+2)},oe:function(a){return 1-c.cos(c.PI/2*a)},ne:function(a){return c.sin(c.PI/2*a)},ve:function(a){return-1/2*(c.cos(c.PI*a)-1)},Ge:function(a){return a==0?0:c.pow(2,10*(a-1))},He:function(a){return a==1?1:-c.pow(2,-10*a)+1},Ie:function(a){return a==0||a==1?a:(a*=2)<1?1/2*c.pow(2,10*(a-1)):1/2*(-c.pow(2,-10*--a)+2)},bf:function(a){return-(c.sqrt(1-a*a)-1)},af:function(a){return c.sqrt(1-(a-=1)*a)},Ze:function(a){return(a*=2)<1?-1/2*(c.sqrt(1-a*a)-1):1/2*(c.sqrt(1-(a-=2)*a)+1)},Ye:function(a){if(!a||a==1)return a;var b=.3,d=.075;return-(c.pow(2,10*(a-=1))*c.sin((a-d)*2*c.PI/b))},Ve:function(a){if(!a||a==1)return a;var b=.3,d=.075;return c.pow(2,-10*a)*c.sin((a-d)*2*c.PI/b)+1},Ue:function(a){if(!a||a==1)return a;var b=.45,d=.1125;return(a*=2)<1?-.5*c.pow(2,10*(a-=1))*c.sin((a-d)*2*c.PI/b):c.pow(2,-10*(a-=1))*c.sin((a-d)*2*c.PI/b)*.5+1},Te:function(a){var b=1.70158;return a*a*((b+1)*a-b)},Se:function(a){var b=1.70158;return(a-=1)*a*((b+1)*a+b)+1},Re:function(a){var b=1.70158;return(a*=2)<1?1/2*a*a*(((b*=1.525)+1)*a-b):1/2*((a-=2)*a*(((b*=1.525)+1)*a+b)+2)},ld:function(a){return 1-e.Xb(1-a)},Xb:function(a){return a<1/2.75?7.5625*a*a:a<2/2.75?7.5625*(a-=1.5/2.75)*a+.75:a<2.5/2.75?7.5625*(a-=2.25/2.75)*a+.9375:7.5625*(a-=2.625/2.75)*a+.984375},Me:function(a){return a<1/2?e.ld(a*2)*.5:e.Xb(a*2-1)*.5+.5},Le:function(){return 1-c.abs(1)},cf:function(a){return 1-c.cos(a*c.PI*2)},Fd:function(a){return c.sin(a*c.PI*2)},Dd:function(a){return 1-((a*=2)<1?(a=1-a)*a*a:(a-=1)*a*a)},Pd:function(a){return(a*=2)<1?a*a*a:(a=2-a)*a*a}},f={Hd:e.sd,Id:e.ud,Kd:e.Yf,Ld:e.Bd,Md:e.Ce,Rd:e.Ae,ie:e.ze,ge:e.ye,ee:e.xe,be:e.Fe,Yd:e.we,Wd:e.te,td:e.qe,Ud:e.pe,Td:e.oe,Qd:e.ne,le:e.ve,Sd:e.Ge,Vd:e.He,Xd:e.Ie,ce:e.bf,fe:e.af,ae:e.Ze,Od:e.Ye,Cd:e.Ve,Ke:e.Ue,df:e.Te,qf:e.Se,eg:e.Re,bg:e.ld,ag:e.Xb,ef:e.Me,Xf:e.Le,Wf:e.cf,Vf:e.Fd,Uf:e.Dd,hg:e.Pd};var b=new function(){var f=this,Ab=/\S+/g,F=1,yb=2,fb=3,eb=4,jb=5,G,r=0,i=0,s=0,X=0,z=0,I=navigator,ob=I.appName,o=I.userAgent,p=parseFloat;function Ib(){if(!G){G={gf:"ontouchstart"in g||"createTouch"in h};var a;if(I.pointerEnabled||(a=I.msPointerEnabled))G.nd=a?"msTouchAction":"touchAction"}return G}function v(j){if(!r){r=-1;if(ob=="Microsoft Internet Explorer"&&!!g.attachEvent&&!!g.ActiveXObject){var e=o.indexOf("MSIE");r=F;s=p(o.substring(e+5,o.indexOf(";",e)));/*@cc_on X=@_jscript_version@*/;i=h.documentMode||s}else if(ob=="Netscape"&&!!g.addEventListener){var d=o.indexOf("Firefox"),b=o.indexOf("Safari"),f=o.indexOf("Chrome"),c=o.indexOf("AppleWebKit");if(d>=0){r=yb;i=p(o.substring(d+8))}else if(b>=0){var k=o.substring(0,b).lastIndexOf("/");r=f>=0?eb:fb;i=p(o.substring(k+1,b))}else{var a=/Trident\/.*rv:([0-9]{1,}[\.0-9]{0,})/i.exec(o);if(a){r=F;i=s=p(a[1])}}if(c>=0)z=p(o.substring(c+12))}else{var a=/(opera)(?:.*version|)[ \/]([\w.]+)/i.exec(o);if(a){r=jb;i=p(a[2])}}}return j==r}function q(){return v(F)}function Q(){return q()&&(i<6||h.compatMode=="BackCompat")}function db(){return v(fb)}function ib(){return v(jb)}function vb(){return db()&&z>534&&z<535}function J(){v();return z>537||i>42||r==F&&i>=11}function O(){return q()&&i<9}function wb(a){var b,c;return function(f){if(!b){b=d;var e=a.substr(0,1).toUpperCase()+a.substr(1);n([a].concat(["WebKit","ms","Moz","O","webkit"]),function(g,d){var b=a;if(d)b=g+e;if(f.style[b]!=k)return c=b})}return c}}function ub(b){var a;return function(c){a=a||wb(b)(c)||b;return a}}var K=ub("transform");function nb(a){return{}.toString.call(a)}var kb={};n(["Boolean","Number","String","Function","Array","Date","RegExp","Object"],function(a){kb["[object "+a+"]"]=a.toLowerCase()});function n(b,d){var a,c;if(nb(b)=="[object Array]"){for(a=0;a<b.length;a++)if(c=d(b[a],a,b))return c}else for(a in b)if(c=d(b[a],a,b))return c}function C(a){return a==j?String(a):kb[nb(a)]||"object"}function lb(a){for(var b in a)return d}function A(a){try{return C(a)=="object"&&!a.nodeType&&a!=a.window&&(!a.constructor||{}.hasOwnProperty.call(a.constructor.prototype,"isPrototypeOf"))}catch(b){}}function u(a,b){return{x:a,y:b}}function rb(b,a){setTimeout(b,a||0)}function H(b,d,c){var a=!b||b=="inherit"?"":b;n(d,function(c){var b=c.exec(a);if(b){var d=a.substr(0,b.index),e=a.substr(b.index+b[0].length+1,a.length-1);a=d+e}});a=c+(!a.indexOf(" ")?"":" ")+a;return a}function tb(b,a){if(i<9)b.style.filter=a}f.nf=Ib;f.pd=q;f.Lf=db;f.Hf=J;wb("transform");f.zd=function(){return i};f.xd=rb;function Y(a){a.constructor===Y.caller&&a.Ad&&a.Ad.apply(a,Y.caller.arguments)}f.Ad=Y;f.Cb=function(a){if(f.zf(a))a=h.getElementById(a);return a};function t(a){return a||g.event}f.wd=t;f.mc=function(b){b=t(b);var a=b.target||b.srcElement||h;if(a.nodeType==3)a=f.yd(a);return a};f.fd=function(a){a=t(a);return{x:a.pageX||a.clientX||0,y:a.pageY||a.clientY||0}};function D(c,d,a){if(a!==k)c.style[d]=a==k?"":a;else{var b=c.currentStyle||c.style;a=b[d];if(a==""&&g.getComputedStyle){b=c.ownerDocument.defaultView.getComputedStyle(c,j);b&&(a=b.getPropertyValue(d)||b[d])}return a}}function ab(b,c,a,d){if(a!==k){if(a==j)a="";else d&&(a+="px");D(b,c,a)}else return p(D(b,c))}function m(c,a){var d=a?ab:D,b;if(a&4)b=ub(c);return function(e,f){return d(e,b?b(e):c,f,a&2)}}function Db(b){if(q()&&s<9){var a=/opacity=([^)]*)/.exec(b.style.filter||"");return a?p(a[1])/100:1}else return p(b.style.opacity||"1")}function Fb(b,a,f){if(q()&&s<9){var h=b.style.filter||"",i=new RegExp(/[\s]*alpha\([^\)]*\)/g),e=c.round(100*a),d="";if(e<100||f)d="alpha(opacity="+e+") ";var g=H(h,[i],d);tb(b,g)}else b.style.opacity=a==1?"":c.round(a*100)/100}var L={ab:["rotate"],Y:["rotateX"],V:["rotateY"],Sb:["skewX"],Ob:["skewY"]};if(!J())L=B(L,{v:["scaleX",2],p:["scaleY",2],Z:["translateZ",1]});function M(d,a){var c="";if(a){if(q()&&i&&i<10){delete a.Y;delete a.V;delete a.Z}b.c(a,function(d,b){var a=L[b];if(a){var e=a[1]||0;if(N[b]!=d)c+=" "+a[0]+"("+d+(["deg","px",""])[e]+")"}});if(J()){if(a.hb||a.ib||a.Z)c+=" translate3d("+(a.hb||0)+"px,"+(a.ib||0)+"px,"+(a.Z||0)+"px)";if(a.v==k)a.v=1;if(a.p==k)a.p=1;if(a.v!=1||a.p!=1)c+=" scale3d("+a.v+", "+a.p+", 1)"}}d.style[K(d)]=c}f.Ac=m("transformOrigin",4);f.Af=m("backfaceVisibility",4);f.Bf=m("transformStyle",4);f.Cf=m("perspective",6);f.Df=m("perspectiveOrigin",4);f.Ef=function(a,b){if(q()&&s<9||s<10&&Q())a.style.zoom=b==1?"":b;else{var c=K(a),f="scale("+b+")",e=a.style[c],g=new RegExp(/[\s]*scale\(.*?\)/g),d=H(e,[g],f);a.style[c]=d}};f.qc=function(b,a){return function(c){c=t(c);var e=c.type,d=c.relatedTarget||(e=="mouseout"?c.toElement:c.fromElement);(!d||d!==a&&!f.Gf(a,d))&&b(c)}};f.a=function(a,d,b,c){a=f.Cb(a);if(a.addEventListener){d=="mousewheel"&&a.addEventListener("DOMMouseScroll",b,c);a.addEventListener(d,b,c)}else if(a.attachEvent){a.attachEvent("on"+d,b);c&&a.setCapture&&a.setCapture()}};f.I=function(a,c,d,b){a=f.Cb(a);if(a.removeEventListener){c=="mousewheel"&&a.removeEventListener("DOMMouseScroll",d,b);a.removeEventListener(c,d,b)}else if(a.detachEvent){a.detachEvent("on"+c,d);b&&a.releaseCapture&&a.releaseCapture()}};f.Tb=function(a){a=t(a);a.preventDefault&&a.preventDefault();a.cancel=d;a.returnValue=l};f.Jf=function(a){a=t(a);a.stopPropagation&&a.stopPropagation();a.cancelBubble=d};f.H=function(d,c){var a=[].slice.call(arguments,2),b=function(){var b=a.concat([].slice.call(arguments,0));return c.apply(d,b)};return b};f.Kf=function(a,b){if(b==k)return a.textContent||a.innerText;var c=h.createTextNode(b);f.xc(a);a.appendChild(c)};f.yb=function(d,c){for(var b=[],a=d.firstChild;a;a=a.nextSibling)(c||a.nodeType==1)&&b.push(a);return b};function mb(a,c,e,b){b=b||"u";for(a=a?a.firstChild:j;a;a=a.nextSibling)if(a.nodeType==1){if(U(a,b)==c)return a;if(!e){var d=mb(a,c,e,b);if(d)return d}}}f.F=mb;function S(a,d,f,b){b=b||"u";var c=[];for(a=a?a.firstChild:j;a;a=a.nextSibling)if(a.nodeType==1){U(a,b)==d&&c.push(a);if(!f){var e=S(a,d,f,b);if(e.length)c=c.concat(e)}}return c}function gb(a,c,d){for(a=a?a.firstChild:j;a;a=a.nextSibling)if(a.nodeType==1){if(a.tagName==c)return a;if(!d){var b=gb(a,c,d);if(b)return b}}}f.jf=gb;f.lf=function(b,a){return b.getElementsByTagName(a)};function B(){var e=arguments,d,c,b,a,g=1&e[0],f=1+g;d=e[f-1]||{};for(;f<e.length;f++)if(c=e[f])for(b in c){a=c[b];if(a!==k){a=c[b];var h=d[b];d[b]=g&&(A(h)||A(a))?B(g,{},h,a):a}}return d}f.K=B;function Z(f,g){var d={},c,a,b;for(c in f){a=f[c];b=g[c];if(a!==b){var e;if(A(a)&&A(b)){a=Z(a,b);e=!lb(a)}!e&&(d[c]=a)}}return d}f.Qc=function(a){return C(a)=="function"};f.zf=function(a){return C(a)=="string"};f.ec=function(a){return!isNaN(p(a))&&isFinite(a)};f.c=n;f.vf=A;function R(a){return h.createElement(a)}f.Nb=function(){return R("DIV")};f.sf=function(){return R("SPAN")};f.cd=function(){};function V(b,c,a){if(a==k)return b.getAttribute(c);b.setAttribute(c,a)}function U(a,b){return V(a,b)||V(a,"data-"+b)}f.s=V;f.g=U;function x(b,a){if(a==k)return b.className;b.className=a}f.bd=x;function qb(b){var a={};n(b,function(b){if(b!=k)a[b]=b});return a}function sb(b,a){return b.match(a||Ab)}function P(b,a){return qb(sb(b||"",a))}f.Of=sb;function bb(b,c){var a="";n(c,function(c){a&&(a+=b);a+=c});return a}function E(a,c,b){x(a,bb(" ",B(Z(P(x(a)),P(c)),P(b))))}f.yd=function(a){return a.parentNode};f.R=function(a){f.P(a,"none")};f.O=function(a,b){f.P(a,b?"none":"")};f.lg=function(b,a){b.removeAttribute(a)};f.og=function(){return q()&&i<10};f.pg=function(d,a){if(a)d.style.clip="rect("+c.round(a.i||a.q||0)+"px "+c.round(a.E)+"px "+c.round(a.D)+"px "+c.round(a.j||a.u||0)+"px)";else if(a!==k){var g=d.style.cssText,f=[new RegExp(/[\s]*clip: rect\(.*?\)[;]?/i),new RegExp(/[\s]*cliptop: .*?[;]?/i),new RegExp(/[\s]*clipright: .*?[;]?/i),new RegExp(/[\s]*clipbottom: .*?[;]?/i),new RegExp(/[\s]*clipleft: .*?[;]?/i)],e=H(g,f,"");b.Jb(d,e)}};f.L=function(){return+new Date};f.S=function(b,a){b.appendChild(a)};f.Kb=function(b,a,c){(c||a.parentNode).insertBefore(b,a)};f.Lb=function(b,a){a=a||b.parentNode;a&&a.removeChild(b)};f.Sf=function(a,b){n(a,function(a){f.Lb(a,b)})};f.xc=function(a){f.Sf(f.yb(a,d),a)};f.Tf=function(a,b){var c=f.yd(a);b&1&&f.B(a,(f.l(c)-f.l(a))/2);b&2&&f.A(a,(f.m(c)-f.m(a))/2)};f.Fb=function(b,a){return parseInt(b,a||10)};f.Zf=p;f.Gf=function(b,a){var c=h.body;while(a&&b!==a&&c!==a)try{a=a.parentNode}catch(d){return l}return b===a};function W(d,c,b){var a=d.cloneNode(!c);!b&&f.lg(a,"id");return a}f.nb=W;f.mb=function(e,g){var a=new Image;function b(e,d){f.I(a,"load",b);f.I(a,"abort",c);f.I(a,"error",c);g&&g(a,d)}function c(a){b(a,d)}if(ib()&&i<11.6||!e)b(!e);else{f.a(a,"load",b);f.a(a,"abort",c);f.a(a,"error",c);a.src=e}};f.cg=function(d,a,e){var c=d.length+1;function b(b){c--;if(a&&b&&b.src==a.src)a=b;!c&&e&&e(a)}n(d,function(a){f.mb(a.src,b)});b()};f.dg=function(a,g,i,h){if(h)a=W(a);var c=S(a,g);if(!c.length)c=b.lf(a,g);for(var f=c.length-1;f>-1;f--){var d=c[f],e=W(i);x(e,x(d));b.Jb(e,d.style.cssText);b.Kb(e,d);b.Lb(d)}return a};function Gb(a){var l=this,p="",r=["av","pv","ds","dn"],e=[],q,j=0,g=0,d=0;function i(){E(a,q,e[d||j||g&2||g]);b.M(a,"pointer-events",d?"none":"")}function c(){j=0;i();f.I(h,"mouseup",c);f.I(h,"touchend",c);f.I(h,"touchcancel",c)}function o(a){if(d)f.Tb(a);else{j=4;i();f.a(h,"mouseup",c);f.a(h,"touchend",c);f.a(h,"touchcancel",c)}}l.ff=function(a){if(a===k)return g;g=a&2||a&1;i()};l.Ib=function(a){if(a===k)return!d;d=a?0:3;i()};l.N=a=f.Cb(a);var m=b.Of(x(a));if(m)p=m.shift();n(r,function(a){e.push(p+a)});q=bb(" ",e);e.unshift("");f.a(a,"mousedown",o);f.a(a,"touchstart",o)}f.kc=function(a){return new Gb(a)};f.M=D;f.Pb=m("overflow");f.A=m("top",2);f.B=m("left",2);f.l=m("width",2);f.m=m("height",2);f.Cc=m("marginLeft",2);f.gd=m("marginTop",2);f.z=m("position");f.P=m("display");f.n=m("zIndex",1);f.pc=function(b,a,c){if(a!=k)Fb(b,a,c);else return Db(b)};f.Jb=function(a,b){if(b!=k)a.style.cssText=b;else return a.style.cssText};var T={rb:f.pc,i:f.A,j:f.B,sb:f.l,tb:f.m,ub:f.z,Ig:f.P,kb:f.n};function w(g,l){var e=O(),b=J(),d=vb(),h=K(g);function i(b,d,a){var e=b.bb(u(-d/2,-a/2)),f=b.bb(u(d/2,-a/2)),g=b.bb(u(d/2,a/2)),h=b.bb(u(-d/2,a/2));b.bb(u(300,300));return u(c.min(e.x,f.x,g.x,h.x)+d/2,c.min(e.y,f.y,g.y,h.y)+a/2)}function a(d,a){a=a||{};var n=a.Z||0,p=(a.Y||0)%360,q=(a.V||0)%360,u=(a.ab||0)%360,l=a.v,m=a.p,g=a.Gg;if(l==k)l=1;if(m==k)m=1;if(g==k)g=1;if(e){n=0;p=0;q=0;g=0}var c=new Cb(a.hb,a.ib,n);c.Y(p);c.V(q);c.ke(u);c.de(a.Sb,a.Ob);c.tc(l,m,g);if(b){c.Bb(a.u,a.q);d.style[h]=c.he()}else if(!X||X<9){var o="",j={x:0,y:0};if(a.T)j=i(c,a.T,a.cb);f.gd(d,j.y);f.Cc(d,j.x);o=c.Nd();var s=d.style.filter,t=new RegExp(/[\s]*progid:DXImageTransform\.Microsoft\.Matrix\([^\)]*\)/g),r=H(s,[t],o);tb(d,r)}}w=function(e,c){c=c||{};var h=c.u,i=c.q,g;n(T,function(a,b){g=c[b];g!==k&&a(e,g)});f.pg(e,c.f);if(!b){h!=k&&f.B(e,(c.Uc||0)+h);i!=k&&f.A(e,(c.Tc||0)+i)}if(c.Jd)if(d)rb(f.H(j,M,e,c));else a(e,c)};f.Qb=M;if(d)f.Qb=w;if(e)f.Qb=a;else if(!b)a=M;f.Q=w;w(g,l)}f.Qb=w;f.Q=w;function Cb(i,k,o){var d=this,b=[1,0,0,0,0,1,0,0,0,0,1,0,i||0,k||0,o||0,1],h=c.sin,g=c.cos,l=c.tan;function f(a){return a*c.PI/180}function n(a,b){return{x:a,y:b}}function m(c,e,l,m,o,r,t,u,w,z,A,C,E,b,f,k,a,g,i,n,p,q,s,v,x,y,B,D,F,d,h,j){return[c*a+e*p+l*x+m*F,c*g+e*q+l*y+m*d,c*i+e*s+l*B+m*h,c*n+e*v+l*D+m*j,o*a+r*p+t*x+u*F,o*g+r*q+t*y+u*d,o*i+r*s+t*B+u*h,o*n+r*v+t*D+u*j,w*a+z*p+A*x+C*F,w*g+z*q+A*y+C*d,w*i+z*s+A*B+C*h,w*n+z*v+A*D+C*j,E*a+b*p+f*x+k*F,E*g+b*q+f*y+k*d,E*i+b*s+f*B+k*h,E*n+b*v+f*D+k*j]}function e(c,a){return m.apply(j,(a||b).concat(c))}d.tc=function(a,c,d){if(a!=1||c!=1||d!=1)b=e([a,0,0,0,0,c,0,0,0,0,d,0,0,0,0,1])};d.Bb=function(a,c,d){b[12]+=a||0;b[13]+=c||0;b[14]+=d||0};d.Y=function(c){if(c){a=f(c);var d=g(a),i=h(a);b=e([1,0,0,0,0,d,i,0,0,-i,d,0,0,0,0,1])}};d.V=function(c){if(c){a=f(c);var d=g(a),i=h(a);b=e([d,0,-i,0,0,1,0,0,i,0,d,0,0,0,0,1])}};d.ke=function(c){if(c){a=f(c);var d=g(a),i=h(a);b=e([d,i,0,0,-i,d,0,0,0,0,1,0,0,0,0,1])}};d.de=function(a,c){if(a||c){i=f(a);k=f(c);b=e([1,l(k),0,0,l(i),1,0,0,0,0,1,0,0,0,0,1])}};d.bb=function(c){var a=e(b,[1,0,0,0,0,1,0,0,0,0,1,0,c.x,c.y,0,1]);return n(a[12],a[13])};d.he=function(){return"matrix3d("+b.join(",")+")"};d.Nd=function(){return"progid:DXImageTransform.Microsoft.Matrix(M11="+b[0]+", M12="+b[4]+", M21="+b[1]+", M22="+b[5]+", SizingMethod='auto expand')"}}new function(){var a=this;function b(d,g){for(var j=d[0].length,i=d.length,h=g[0].length,f=[],c=0;c<i;c++)for(var k=f[c]=[],b=0;b<h;b++){for(var e=0,a=0;a<j;a++)e+=d[c][a]*g[a][b];k[b]=e}return f}a.v=function(b,c){return a.ed(b,c,0)};a.p=function(b,c){return a.ed(b,0,c)};a.ed=function(a,c,d){return b(a,[[c,0],[0,d]])};a.bb=function(d,c){var a=b(d,[[c.x],[c.y]]);return u(a[0][0],a[1][0])}};var N={Uc:0,Tc:0,u:0,q:0,eb:1,v:1,p:1,ab:0,Y:0,V:0,hb:0,ib:0,Z:0,Sb:0,Ob:0};f.Rc=function(a){var c=a||{};if(a)if(b.Qc(a))c={ic:c};else if(b.Qc(a.f))c.f={ic:a.f};return c};function pb(c,a){var b={};n(c,function(c,d){var e=c;if(a[d]!=k)if(f.ec(c))e=c+a[d];else e=pb(c,a[d]);b[d]=e});return b}f.me=pb;f.Je=function(l,m,x,q,z,A,n){var a=m;if(l){a={};for(var g in m){var B=A[g]||1,w=z[g]||[0,1],f=(x-w[0])/w[1];f=c.min(c.max(f,0),1);f=f*B;var u=c.floor(f);if(f!=u)f-=u;var h=q.ic||e.sd,i,C=l[g],o=m[g];if(b.ec(o)){h=q[g]||h;var y=h(f);i=C+o*y}else{i=b.K({Ub:{}},l[g]);var v=q[g]||{};b.c(o.Ub||o,function(d,a){h=v[a]||v.ic||h;var c=h(f),b=d*c;i.Ub[a]=b;i[a]+=b})}a[g]=i}var t=b.c(m,function(b,a){return N[a]!=k});t&&b.c(N,function(c,b){if(a[b]==k&&l[b]!==k)a[b]=l[b]});if(t){if(a.eb)a.v=a.p=a.eb;a.T=n.T;a.cb=n.cb;a.Jd=d}}if(m.f&&n.Bb){var p=a.f.Ub,s=(p.i||0)+(p.D||0),r=(p.j||0)+(p.E||0);a.j=(a.j||0)+r;a.i=(a.i||0)+s;a.f.j-=r;a.f.E-=r;a.f.i-=s;a.f.D-=s}if(a.f&&b.og()&&!a.f.i&&!a.f.j&&!a.f.q&&!a.f.u&&a.f.E==n.T&&a.f.D==n.cb)a.f=j;return a}};function n(){var a=this,d=[];function i(a,b){d.push({Wb:a,Zb:b})}function h(a,c){b.c(d,function(b,e){b.Wb==a&&b.Zb===c&&d.splice(e,1)})}a.Ab=a.addEventListener=i;a.removeEventListener=h;a.k=function(a){var c=[].slice.call(arguments,1);b.c(d,function(b){b.Wb==a&&b.Zb.apply(g,c)})}}var m=function(z,C,f,K,N,M){z=z||0;var a=this,q,o,p,u,A=0,G,H,F,B,y=0,i=0,m=0,D,k,e,h,n,J,w=[],x;function P(a){e+=a;h+=a;k+=a;i+=a;m+=a;y+=a}function t(p){var g=p;if(n){if(g>=h||g<=e&&!J)g=((g-e)%n+n)%n+e;if(f.We&&g<=e)g=e+n}if(!D||u||i!=g){var j=c.min(g,h);j=c.max(j,e);if(!D||u||j!=m){if(M){var l=(j-k)/(C||1);if(f.Xe)l=1-l;var o=b.Je(N,M,l,G,F,H,f);if(x)b.c(o,function(b,a){x[a]&&x[a](K,b)});else b.Q(K,o)}a.bc(m-k,j-k);var r=m,q=m=j;b.c(w,function(b,c){var a=g<i?w[w.length-c-1]:b;a.C(m-y)});i=g;D=d;a.Rb(r,q)}}}function E(a,b,d){b&&a.gb(h);if(!d){e=c.min(e,a.Vb()+y);h=c.max(h,a.ob()+y)}w.push(a)}var r=g.requestAnimationFrame||g.webkitRequestAnimationFrame||g.mozRequestAnimationFrame||g.msRequestAnimationFrame;if(b.Lf()&&b.zd()<7)r=j;r=r||function(a){b.xd(a,f.Nc)};function I(){if(q){var d=b.L(),e=c.min(d-A,f.Mc),a=i+e*p;A=d;if(a*p>=o*p)a=o;t(a);if(!u&&a*p>=o*p)L(B);else r(I)}}function s(f,g,j){if(!q){q=d;u=j;B=g;f=c.max(f,e);f=c.min(f,h);o=f;p=o<i?-1:1;a.Lc();A=b.L();r(I)}}function L(b){if(q){u=q=B=l;a.Kc();b&&b()}}a.Jc=function(a,b,c){s(a?i+a:h,b,c)};a.Ic=s;a.db=L;a.ue=function(a){s(a)};a.U=function(){return i};a.Hc=function(){return o};a.pb=function(){return m};a.C=t;a.Bb=function(a){t(i+a)};a.Fc=function(){return q};a.Ee=function(a){n=a};a.gb=P;a.W=function(a,b){E(a,0,b)};a.nc=function(a){E(a,1)};a.ig=function(a){h+=a};a.Vb=function(){return e};a.ob=function(){return h};a.Rb=a.Lc=a.Kc=a.bc=b.cd;a.oc=b.L();f=b.K({Nc:16,Mc:50},f);n=f.sc;J=f.gg;x=f.mg;e=k=z;h=z+C;H=f.xg||{};F=f.wg||{};G=b.Rc(f.X)};new(function(){});var i=function(p,fc){var f=this;function Bc(){var a=this;m.call(a,-1e8,2e8);a.xf=function(){var b=a.pb(),d=c.floor(b),f=t(d),e=b-c.floor(b);return{fb:f,wf:d,ub:e}};a.Rb=function(b,a){var e=c.floor(a);if(e!=a&&a>b)e++;Tb(e,d);f.k(i.hf,t(a),t(b),a,b)}}function Ac(){var a=this;m.call(a,0,0,{sc:r});b.c(C,function(b){D&1&&b.Ee(r);a.nc(b);b.gb(kb/bc)})}function zc(){var a=this,b=Ub.N;m.call(a,-1,2,{X:e.ud,mg:{ub:Zb},sc:r},b,{ub:1},{ub:-2});a.jc=b}function mc(o,n){var b=this,e,g,h,k,c;m.call(b,-1e8,2e8,{Mc:100});b.Lc=function(){M=d;R=j;f.k(i.yg,t(w.U()),w.U())};b.Kc=function(){M=l;k=l;var a=w.xf();f.k(i.qg,t(w.U()),w.U());!a.ub&&Dc(a.wf,s)};b.Rb=function(i,f){var b;if(k)b=c;else{b=g;if(h){var d=f/h;b=a.Ec(d)*(g-e)+e}}w.C(b)};b.Hb=function(a,d,c,f){e=a;g=d;h=c;w.C(a);b.C(0);b.Ic(c,f)};b.Be=function(a){k=d;c=a;b.Jc(a,j,d)};b.De=function(a){c=a};w=new Bc;w.W(o);w.W(n)}function oc(){var c=this,a=Xb();b.n(a,0);b.M(a,"pointerEvents","none");c.N=a;c.Mb=function(){b.R(a);b.xc(a)}}function xc(o,g){var e=this,q,M,v,k,y=[],x,B,W,H,S,F,h,w,p;m.call(e,-u,u+1,{});function E(a){q&&q.Gc();T(o,a,0);F=d;q=new I.G(o,I,b.Zf(b.g(o,"idle"))||lc);q.C(0)}function Z(){q.oc<I.oc&&E()}function O(p,r,o){if(!H){H=d;if(k&&o){var h=o.width,c=o.height,n=h,m=c;if(h&&c&&a.vb){if(a.vb&3&&(!(a.vb&4)||h>K||c>J)){var j=l,q=K/J*c/h;if(a.vb&1)j=q>1;else if(a.vb&2)j=q<1;n=j?h*J/c:K;m=j?J:c*K/h}b.l(k,n);b.m(k,m);b.A(k,(J-m)/2);b.B(k,(K-n)/2)}b.z(k,"absolute");f.k(i.se,g)}}b.R(r);p&&p(e)}function Y(b,c,d,f){if(f==R&&s==g&&N)if(!Cc){var a=t(b);A.If(a,g,c,e,d);c.re();U.gb(a-U.Vb()-1);U.C(a);z.Hb(b,b,0)}}function bb(b){if(b==R&&s==g){if(!h){var a=j;if(A)if(A.fb==g)a=A.yf();else A.Mb();Z();h=new vc(o,g,a,q);h.Oc(p)}!h.Fc()&&h.hc()}}function G(d,f,l){if(d==g){if(d!=f)C[f]&&C[f].Pc();else!l&&h&&h.Qe();p&&p.Ib();var m=R=b.L();e.mb(b.H(j,bb,m))}else{var k=c.min(g,d),i=c.max(g,d),o=c.min(i-k,k+r-i),n=u+a.Pe-1;(!S||o<=n)&&e.mb()}}function db(){if(s==g&&h){h.db();p&&p.Oe();p&&p.Ne();h.Sc()}}function eb(){s==g&&h&&h.db()}function ab(a){!P&&f.k(i.Ed,g,a)}function Q(){p=w.pInstance;h&&h.Oc(p)}e.mb=function(c,a){a=a||v;if(y.length&&!H){b.O(a);if(!W){W=d;f.k(i.je,g);b.c(y,function(a){if(!b.s(a,"src")){a.src=b.g(a,"src2");b.P(a,a["display-origin"])}})}b.cg(y,k,b.H(j,O,c,a))}else O(c,a)};e.Zd=function(){var i=g;if(a.Vc<0)i-=r;var d=i+a.Vc*tc;if(D&2)d=t(d);if(!(D&1)&&!ib)d=c.max(0,c.min(d,r-u));if(d!=g){if(A){var f=A.Ff(r);if(f){var k=R=b.L(),h=C[t(d)];return h.mb(b.H(j,Y,d,h,f,k),v)}}cb(d)}else if(a.qb){e.Pc();G(g,g)}};e.lc=function(){G(g,g,d)};e.Pc=function(){p&&p.Oe();p&&p.Ne();e.Xc();h&&h.Rf();h=j;E()};e.re=function(){b.R(o)};e.Xc=function(){b.O(o)};e.fg=function(){p&&p.Ib()};function T(a,c,e){if(b.s(a,"jssor-slider"))return;if(!F){if(a.tagName=="IMG"){y.push(a);if(!b.s(a,"src")){S=d;a["display-origin"]=b.P(a);b.R(a)}}e&&b.n(a,(b.n(a)||0)+1);b.gd(a,0);b.Cc(a,0)}var f=b.yb(a);b.c(f,function(f){var h=f.tagName,i=b.g(f,"u");if(i=="player"&&!w){w=f;if(w.pInstance)Q();else b.a(w,"dataavailable",Q)}if(i=="caption"){if(c){b.Ac(f,b.g(f,"to"));b.Af(f,b.g(f,"bf"));b.g(f,"3d")&&b.Bf(f,"preserve-3d")}else if(!b.pd()){var g=b.nb(f,l,d);b.Kb(g,f,a);b.Lb(f,a);f=g;c=d}}else if(!F&&!e&&!k){if(h=="A"){if(b.g(f,"u")=="image")k=b.jf(f,"IMG");else k=b.F(f,"image",d);if(k){x=f;b.P(x,"block");b.Q(x,V);B=b.nb(x,d);b.z(x,"relative");b.pc(B,0);b.M(B,"backgroundColor","#000")}}else if(h=="IMG"&&b.g(f,"u")=="image")k=f;if(k){k.border=0;b.Q(k,V)}}T(f,c,e+1)})}e.bc=function(c,b){var a=u-b;Zb(M,a)};e.fb=g;n.call(e);b.Cf(o,b.g(o,"p"));b.Df(o,b.g(o,"po"));var L=b.F(o,"thumb",d);if(L){b.nb(L);b.R(L)}b.O(o);v=b.nb(gb);b.n(v,1e3);b.a(o,"click",ab);E(d);e.Mf=k;e.Yc=B;e.jc=M=o;b.S(M,v);f.Ab(203,G);f.Ab(28,eb);f.Ab(24,db)}function vc(y,g,p,q){var a=this,n=0,u=0,h,j,e,c,k,t,r,o=C[g];m.call(a,0,0);function v(){b.xc(L);cc&&k&&o.Yc&&b.S(L,o.Yc);b.O(L,!k&&o.Mf)}function w(){a.hc()}function x(b){r=b;a.db();a.hc()}a.hc=function(){var b=a.pb();if(!B&&!M&&!r&&s==g){if(!b){if(h&&!k){k=d;a.Sc(d);f.k(i.kg,g,n,u,h,c)}v()}var l,p=i.Zc;if(b!=c)if(b==e)l=c;else if(b==j)l=e;else if(!b)l=j;else l=a.Hc();f.k(p,g,b,n,j,e,c);var m=N&&(!E||F);if(b==c)(e!=c&&!(E&12)||m)&&o.Zd();else(m||b!=e)&&a.Ic(l,w)}};a.Qe=function(){e==c&&e==a.pb()&&a.C(j)};a.Rf=function(){A&&A.fb==g&&A.Mb();var b=a.pb();b<c&&f.k(i.Zc,g,-b-1,n,j,e,c)};a.Sc=function(a){p&&b.Pb(lb,a&&p.Yb.Fg?"":"hidden")};a.bc=function(b,a){if(k&&a>=h){k=l;v();o.Xc();A.Mb();f.k(i.Qf,g,n,u,h,c)}f.k(i.Nf,g,a,n,j,e,c)};a.Oc=function(a){if(a&&!t){t=a;a.Ab($JssorPlayer$.jg,x)}};p&&a.nc(p);h=a.ob();a.nc(q);j=h+q.ad;e=h+q.dd;c=a.ob()}function Kb(a,c,d){b.B(a,c);b.A(a,d)}function Zb(c,b){var a=x>0?x:fb,d=zb*b*(a&1),e=Ab*b*(a>>1&1);Kb(c,d,e)}function Pb(){qb=M;Ib=z.Hc();G=w.U()}function gc(){Pb();if(B||!F&&E&12){z.db();f.k(i.rf)}}function ec(f){if(!B&&(F||!(E&12))&&!z.Fc()){var d=w.U(),b=c.ceil(G);if(f&&c.abs(H)>=a.Dc){b=c.ceil(d);b+=jb}if(!(D&1))b=c.min(r-u,c.max(b,0));var e=c.abs(b-d);e=1-c.pow(1-e,5);if(!P&&qb)z.ue(Ib);else if(d==b){tb.fg();tb.lc()}else z.Hb(d,b,e*Vb)}}function Hb(a){!b.g(b.mc(a),"nodrag")&&b.Tb(a)}function rc(a){Yb(a,1)}function Yb(a,c){a=b.wd(a);var k=b.mc(a);if(!O&&!b.g(k,"nodrag")&&sc()&&(!c||a.touches.length==1)){B=d;yb=l;R=j;b.a(h,c?"touchmove":"mousemove",Bb);b.L();P=0;gc();if(!qb)x=0;if(c){var g=a.touches[0];ub=g.clientX;vb=g.clientY}else{var e=b.fd(a);ub=e.x;vb=e.y}H=0;hb=0;jb=0;f.k(i.Pf,t(G),G,a)}}function Bb(e){if(B){e=b.wd(e);var f;if(e.type!="mousemove"){var l=e.touches[0];f={x:l.clientX,y:l.clientY}}else f=b.fd(e);if(f){var j=f.x-ub,k=f.y-vb;if(c.floor(G)!=G)x=x||fb&O;if((j||k)&&!x){if(O==3)if(c.abs(k)>c.abs(j))x=2;else x=1;else x=O;if(ob&&x==1&&c.abs(k)-c.abs(j)>3)yb=d}if(x){var a=k,i=Ab;if(x==1){a=j;i=zb}if(!(D&1)){if(a>0){var g=i*s,h=a-g;if(h>0)a=g+c.sqrt(h)*5}if(a<0){var g=i*(r-u-s),h=-a-g;if(h>0)a=-g-c.sqrt(h)*5}}if(H-hb<-2)jb=0;else if(H-hb>2)jb=-1;hb=H;H=a;sb=G-H/i/(Y||1);if(H&&x&&!yb){b.Tb(e);if(!M)z.Be(sb);else z.De(sb)}}}}}function bb(){qc();if(B){B=l;b.L();b.I(h,"mousemove",Bb);b.I(h,"touchmove",Bb);P=H;z.db();var a=w.U();f.k(i.pf,t(a),a,t(G),G);E&12&&Pb();ec(d)}}function jc(c){if(P){b.Jf(c);var a=b.mc(c);while(a&&v!==a){a.tagName=="A"&&b.Tb(c);try{a=a.parentNode}catch(d){break}}}}function Jb(a){C[s];s=t(a);tb=C[s];Tb(a);return s}function Dc(a,b){x=0;Jb(a);f.k(i.mf,t(a),b)}function Tb(a,c){wb=a;b.c(S,function(b){b.cc(t(a),a,c)})}function sc(){var b=i.zc||0,a=X;if(ob)a&1&&(a&=1);i.zc|=a;return O=a&~b}function qc(){if(O){i.zc&=~X;O=0}}function Xb(){var a=b.Nb();b.Q(a,V);b.z(a,"absolute");return a}function t(a){return(a%r+r)%r}function kc(b,d){if(d)if(!D){b=c.min(c.max(b+wb,0),r-u);d=l}else if(D&2){b=t(b+wb);d=l}cb(b,a.Eb,d)}function xb(){b.c(S,function(a){a.yc(a.Db.Ag<=F)})}function hc(){if(!F){F=1;xb();if(!B){E&12&&ec();E&3&&C[s].lc()}}}function Ec(){if(F){F=0;xb();B||!(E&12)||gc()}}function ic(){V={sb:K,tb:J,i:0,j:0};b.c(T,function(a){b.Q(a,V);b.z(a,"absolute");b.Pb(a,"hidden");b.R(a)});b.Q(gb,V)}function ab(b,a){cb(b,a,d)}function cb(g,f,j){if(Rb&&(!B&&(F||!(E&12))||a.Bc)){M=d;B=l;z.db();if(f==k)f=Vb;var e=Cb.pb(),b=g;if(j){b=e+g;if(g>0)b=c.ceil(b);else b=c.floor(b)}if(D&2)b=t(b);if(!(D&1))b=c.max(0,c.min(b,r-u));var i=(b-e)%r;b=e+i;var h=e==b?0:f*c.abs(i);h=c.min(h,f*u*1.5);z.Hb(e,b,h||1)}}f.Jc=function(){if(!N){N=d;C[s]&&C[s].lc()}};function W(){return b.l(y||p)}function nb(){return b.m(y||p)}f.T=W;f.cb=nb;function Eb(c,d){if(c==k)return b.l(p);if(!y){var a=b.Nb(h);b.bd(a,b.bd(p));b.Jb(a,b.Jb(p));b.P(a,"block");b.z(a,"relative");b.A(a,0);b.B(a,0);b.Pb(a,"visible");y=b.Nb(h);b.z(y,"absolute");b.A(y,0);b.B(y,0);b.l(y,b.l(p));b.m(y,b.m(p));b.Ac(y,"0 0");b.S(y,a);var g=b.yb(p);b.S(p,y);b.M(p,"backgroundImage","");b.c(g,function(c){b.S(b.g(c,"noscale")?p:a,c);b.g(c,"autocenter")&&Lb.push(c)})}Y=c/(d?b.m:b.l)(y);b.Ef(y,Y);var f=d?Y*W():c,e=d?c:Y*nb();b.l(p,f);b.m(p,e);b.c(Lb,function(a){var c=b.Fb(b.g(a,"autocenter"));b.Tf(a,c)})}f.kf=Eb;n.call(f);f.N=p=b.Cb(p);var a=b.K({vb:0,Pe:1,uc:1,gc:0,fc:l,qb:1,lb:d,Bc:d,Vc:1,jd:3e3,hd:1,Eb:500,Ec:e.Bd,Dc:20,id:0,wb:1,rd:0,tf:1,ac:1,vd:1},fc);a.lb=a.lb&&b.Hf();if(a.uf!=k)a.jd=a.uf;if(a.rg!=k)a.rd=a.rg;var fb=a.ac&3,tc=(a.ac&4)/-4||1,mb=a.Bg,I=b.K({G:q,lb:a.lb},a.ng);I.xb=I.xb||I.Eg;var Fb=a.sg,Z=a.tg,eb=a.Dg,Q=!a.tf,y,v=b.F(p,"slides",Q),gb=b.F(p,"loading",Q)||b.Nb(h),Nb=b.F(p,"navigator",Q),dc=b.F(p,"arrowleft",Q),ac=b.F(p,"arrowright",Q),Mb=b.F(p,"thumbnavigator",Q),pc=b.l(v),nc=b.m(v),V,T=[],uc=b.yb(v);b.c(uc,function(a){a.tagName=="DIV"&&!b.g(a,"u")&&T.push(a);b.n(a,(b.n(a)||0)+1)});var s=-1,wb,tb,r=T.length,K=a.ug||pc,J=a.vg||nc,Wb=a.id,zb=K+Wb,Ab=J+Wb,bc=fb&1?zb:Ab,u=c.min(a.wb,r),lb,x,O,yb,S=[],Qb,Sb,Ob,cc,Cc,N,E=a.hd,lc=a.jd,Vb=a.Eb,rb,ib,kb,Rb=u<r,D=Rb?a.qb:0,X,P,F=1,M,B,R,ub=0,vb=0,H,hb,jb,Cb,w,U,z,Ub=new oc,Y,Lb=[];if(r){if(a.lb)Kb=function(a,c,d){b.Qb(a,{hb:c,ib:d})};N=a.fc;f.Db=fc;ic();b.s(p,"jssor-slider",d);b.n(v,b.n(v)||0);b.z(v,"absolute");lb=b.nb(v,d);b.Kb(lb,v);if(mb){cc=mb.Cg;rb=mb.G;ib=u==1&&r>1&&rb&&(!b.pd()||b.zd()>=8)}kb=ib||u>=r||!(D&1)?0:a.rd;X=(u>1||kb?fb:-1)&a.vd;var Gb=v,C=[],A,L,Db=b.nf(),ob=Db.gf,G,qb,Ib,sb;Db.nd&&b.M(Gb,Db.nd,([j,"pan-y","pan-x","none"])[X]||"");U=new zc;if(ib)A=new rb(Ub,K,J,mb,ob);b.S(lb,U.jc);b.Pb(v,"hidden");L=Xb();b.M(L,"backgroundColor","#000");b.pc(L,0);b.Kb(L,Gb.firstChild,Gb);for(var db=0;db<T.length;db++){var wc=T[db],yc=new xc(wc,db);C.push(yc)}b.R(gb);Cb=new Ac;z=new mc(Cb,U);b.a(v,"click",jc,d);b.a(p,"mouseout",b.qc(hc,p));b.a(p,"mouseover",b.qc(Ec,p));if(X){b.a(v,"mousedown",Yb);b.a(v,"touchstart",rc);b.a(v,"dragstart",Hb);b.a(v,"selectstart",Hb);b.a(h,"mouseup",bb);b.a(h,"touchend",bb);b.a(h,"touchcancel",bb);b.a(g,"blur",bb)}E&=ob?10:5;if(Nb&&Fb){Qb=new Fb.G(Nb,Fb,W(),nb());S.push(Qb)}if(Z&&dc&&ac){Z.qb=D;Z.wb=u;Sb=new Z.G(dc,ac,Z,W(),nb());S.push(Sb)}if(Mb&&eb){eb.gc=a.gc;Ob=new eb.G(Mb,eb);S.push(Ob)}b.c(S,function(a){a.wc(r,C,gb);a.Ab(o.vc,kc)});b.M(p,"visibility","visible");Eb(W());xb();a.uc&&b.a(h,"keydown",function(b){if(b.keyCode==37)ab(-a.uc);else b.keyCode==39&&ab(a.uc)});var pb=a.gc;if(!(D&1))pb=c.max(0,c.min(pb,r-u));z.Hb(pb,pb,0)}};i.Ed=21;i.Pf=22;i.pf=23;i.yg=24;i.qg=25;i.je=26;i.se=27;i.rf=28;i.hf=202;i.mf=203;i.kg=206;i.Qf=207;i.Nf=208;i.Zc=209;var o={vc:1},r=function(e,C){var f=this;n.call(f);e=b.Cb(e);var s,A,z,r,k=0,a,m,i,w,x,h,g,q,p,B=[],y=[];function v(a){a!=-1&&y[a].ff(a==k)}function t(a){f.k(o.vc,a*m)}f.N=e;f.cc=function(a){if(a!=r){var d=k,b=c.floor(a/m);k=b;r=a;v(d);v(b)}};f.yc=function(a){b.O(e,a)};var u;f.wc=function(D){if(!u){s=c.ceil(D/m);k=0;var o=q+w,r=p+x,n=c.ceil(s/i)-1;A=q+o*(!h?n:i-1);z=p+r*(h?n:i-1);b.l(e,A);b.m(e,z);for(var f=0;f<s;f++){var C=b.sf();b.Kf(C,f+1);var l=b.dg(g,"numbertemplate",C,d);b.z(l,"absolute");var v=f%(n+1);b.B(l,!h?o*v:f%i*o);b.A(l,h?r*v:c.floor(f/(n+1))*r);b.S(e,l);B[f]=l;a.rc&1&&b.a(l,"click",b.H(j,t,f));a.rc&2&&b.a(l,"mouseover",b.qc(b.H(j,t,f),l));y[f]=b.kc(l)}u=d}};f.Db=a=b.K({kd:10,qd:10,od:1,rc:1},C);g=b.F(e,"prototype");q=b.l(g);p=b.m(g);b.Lb(g,e);m=a.md||1;i=a.of||1;w=a.kd;x=a.qd;h=a.od-1;a.tc==l&&b.s(e,"noscale",d);a.zb&&b.s(e,"autocenter",a.zb)},s=function(a,g,h){var c=this;n.call(c);var r,e,f,i;b.l(a);b.m(a);var p,m;function k(a){c.k(o.vc,a,d)}function t(c){b.O(a,c);b.O(g,c)}function s(){p.Ib(h.qb||e>0);m.Ib(h.qb||e<r-h.wb)}c.cc=function(b,a,c){if(c)e=a;else{e=b;s()}};c.yc=t;var q;c.wc=function(c){r=c;e=0;if(!q){b.a(a,"click",b.H(j,k,-i));b.a(g,"click",b.H(j,k,i));p=b.kc(a);m=b.kc(g);q=d}};c.Db=f=b.K({md:1},h);i=f.md;if(f.tc==l){b.s(a,"noscale",d);b.s(g,"noscale",d)}if(f.zb){b.s(a,"autocenter",f.zb);b.s(g,"autocenter",f.zb)}};function q(e,d,c){var a=this;m.call(a,0,c);a.Gc=b.cd;a.ad=0;a.dd=c}var t=function(v,g,u){var a=this,w,n={},p=g.xb,r=g.zg,e=new m(0,0),t=[],o=[],h=[];m.call(a,0,0);function q(d,c){var a={};b.c(d,function(d,f){var e=n[f];if(e){if(b.vf(d))d=q(d,c||f=="e");else if(c)if(b.ec(d))d=w[d];a[e]=d}});return a}function s(e,c){var a=[],d=b.yb(e);b.c(d,function(d){var h=b.g(d,"u")=="caption";if(h){var e=b.g(d,"t"),g=p[b.Fb(e)]||p[e],f={N:d,Yb:g};a.push(f)}if(c<5)a=a.concat(s(d,c+1))});return a}function l(c,d,e){var a=0;!b.c(c,function(b,c){a=c;return b.J>e})&&a++;c.splice(a,0,d)}function z(k,n,e){var a;if(r){var i=b.g(k,"c");if(i){var g=r[b.Fb(i)];if(g){a={J:g.r,jb:0,Gb:[],dc:[],Wc:0};l(h,a,g.b)}}}b.c(n,function(g){var f=b.K(d,{},q(g)),i=b.Rc(f.X);delete f.X;if(f.j){f.u=f.j;i.u=i.j;delete f.j}if(f.i){f.q=f.i;i.q=i.i;delete f.i}var p={X:i,T:e.sb,cb:e.tb},n=new m(g.b,g.d,p,k,e,f),h=t[g.b];if(h==j){h={J:g.b,Gb:[]};t[g.b]=h;l(o,h,g.b)}h.Gb.push(n);if(a&&g.b+g.d>a.J){a.jb=c.max(a.jb,g.b+g.d);a.dc.push(n)}e=b.me(e,f)});if(a&&a.dc.length){var f=new m(a.J,a.jb-a.J,{sc:a.jb-a.J,gg:d,We:d});b.c(a.dc,function(a){f.W(a,d)});f.gb(a.jb-a.J);a.Gb=[f]}return e}function y(a){b.c(a,function(d){var a=d.N,f=b.l(a),e=b.m(a),c={j:b.B(a),i:b.A(a),u:0,q:0,rb:1,kb:b.n(a)||0,ab:0,Y:0,V:0,v:1,p:1,hb:0,ib:0,Z:0,Sb:0,Ob:0,sb:f,tb:e,f:{i:0,E:f,D:e,j:0}};c.Uc=c.j;c.Tc=c.i;z(a,d.Yb,c)})}function B(g,f,h){var c=g.b-f;if(c){var b=new m(f,c);b.W(e,d);b.gb(h);a.W(b)}a.ig(g.d);return c}function A(f){var c=e.Vb(),d=0;b.c(f,function(e,f){e=b.K({d:u},e);B(e,c,d);c=e.b;d+=e.d;if(!f||e.t==2){a.ad=c;a.dd=c+e.d}b.c(h,function(a){if(a.jb>e.b)a.Wc+=e.d})})}function i(j,e,a){var f=e.length;if(f>4)for(var k=c.ceil(f/4),d=0;d<k;d++){var g=e.slice(d*4,c.min(d*4+4,f)),h=new m(g[0].J,a||0);i(h,g,a);j.W(h,a)}else b.c(e,function(c){b.c(c.Gb,function(b){b.gb(c.Wc||0);j.W(b,a)})})}a.Gc=function(){a.C(-1,d)};w=[f.Hd,f.Id,f.Kd,f.Ld,f.Md,f.Rd,f.ie,f.ge,f.ee,f.be,f.Yd,f.Wd,f.td,f.Ud,f.Td,f.Qd,f.le,f.Sd,f.Vd,f.Xd,f.ce,f.fe,f.ae,f.Od,f.Cd,f.Ke,f.df,f.qf,f.eg,f.bg,f.ag,f.ef,f.Xf,f.Wf,f.Vf,f.Uf,f.hg];var C={i:"y",j:"x",D:"m",E:"t",ab:"r",Y:"rX",V:"rY",v:"sX",p:"sY",hb:"tX",ib:"tY",Z:"tZ",Sb:"kX",Ob:"kY",rb:"o",X:"e",kb:"i",f:"c"};b.c(C,function(b,a){n[b]=a});y(s(v,1));i(e,o);var x=g.Hg||[],k=[].concat(x[b.Fb(b.g(v,"b"))]||[]);k.push({b:e.ob(),d:k.length?0:u});A(k);i(a,h,a.ob());a.C(-1)};jssor_1_slider_init=function(){var h=[[{b:-1,d:1,o:-1},{b:0,d:1e3,o:1}],[{b:1900,d:2e3,x:-379,e:{x:7}}],[{b:1900,d:2e3,x:-379,e:{x:7}}],[{b:-1,d:1,o:-1,r:288,sX:9,sY:9},{b:1e3,d:900,x:-1400,y:-660,o:1,r:-288,sX:-9,sY:-9,e:{r:6}},{b:1900,d:1600,x:-200,o:-1,e:{x:16}}]],j={fc:d,Eb:800,Ec:f.td,ng:{G:t,xb:h},tg:{G:s},sg:{G:r}},e=new i("jssor_1",j);function a(){var b=e.N.parentNode.clientWidth;if(b){b=c.min(b,1920);e.kf(b)}else g.setTimeout(a,30)}a();b.a(g,"load",a);b.a(g,"resize",a);b.a(g,"orientationchange",a)}})(window,document,Math,null,true,false)
		</script>
</head>
	<style>

			.header {background: url(assets/img/header.jpg);background-size:100% 100% ;background-repeat: no-repeat;background-position:center top;height:800px;transition: margin-left .5s;padding: 16px;margin-top:px;}

			.affix {top:0;width: 100%;-webkit-transition: all .5s ease-in-out;transition: all .5s ease-in-out;}

			@media only screen and (max-width: 768px)
			{
				.header {background: url(assets/img/header-b.jpg);background-size:100% 100% ;background-repeat: no-repeat;background-position:center top;height:800px;transition: margin-left .5s;padding: 16px;}

				!.affix {top: ;width: 100%;-webkit-transition: all .5s ease-in-out;transition: all .5s ease-in-out;opacity:0;}
			}
			.affix-top {position: static;top: -35px;}

			.affix-top a {padding: 25px !important;color:  !important;font-size:18px;-webkit-transition: all .5s ease-in-out;transition: all .5s ease-in-out;}

			.affix-top form {padding-top: 5px !important;color:  !important;-webkit-transition: all .5s ease-in-out;transition: all .5s ease-in-out;}

			.affix a {color: #fff !important;padding: 15px !important;-webkit-transition: all .5s ease-in-out;transition: all .5s ease-in-out;}

			.carousel-control.right, .carousel-control.left {background-image: none;color: white;height:100%;}
			.carousel-indicators li {border-color: orange;}
			.carousel-indicators li.active {background-color: white;}

			.bg-grey {background-color: #f6f6f6;}

			.slide {animation-name: slide;-webkit-animation-name: slide;animation-duration: 1s;-webkit-animation-duration: 1s;visibility: visible;}
			.item h4 {font-size: 19px;line-height: 1.375em;font-weight: 400;font-style: italic;margin: 70px 0;}
			.item span {font-style: normal;}
			.logo {color: blue;font-size: 200px;}

			.logo-small {color: green;font-size: 50px;}


			.panel-head {border: 1px solid #f4511e; border-radius:0 !important;transition: box-shadow 0.5s;}
			.panel {border: 0px solid #f4511e; border-radius:0 !important;transition: box-shadow 0.5s;}

			.panel-head:hover {box-shadow: 5px 0px 40px rgba(0,0,0, .2);}
			.panel-footer .btn:hover {border: 1px solid #f4511e;background-color: #fff !important;color: #f4511e;}
			.panel-heading {color: #fff !important;background-color: #f4511e !important;padding: 25px;border-bottom: 1px solid transparent;border-top-left-radius: 0px;
			  border-top-right-radius: 0px;border-bottom-left-radius: 0px;border-bottom-right-radius: 0px;}
			.panel-footer {background-color: white !important;}
			.panel-footer h3 {font-size: 32px;}
			.panel-footer h4 {color: #aaa;font-size: 14px;}
			.panel-footer .btn {margin: 15px 0;background-color: #f4511e;color: #fff;}
			.slideanim {visibility:visible;}

			.scrollable-menu {height: auto;max-height: 200px;overflow-x: hidden;}

      .party{font-size:15px;}
			@keyframes slide {0% {opacity: 0;transform: translateY(70%);} 100% {opacity: 1;transform: translateY(0%);}}
			@-webkit-keyframes slide {0% {opacity: 0;-webkit-transform: translateY(70%);} 100% {opacity: 1;-webkit-transform: translateY(0%);}}
			@media screen and (max-width: 768px) {.col-sm-4 {text-align: center;margin: 25px 0;}.btn-lg {width: 100%;margin-bottom: 35px;}}
			@media screen and (max-width: 480px) {.logo {font-size: 150px; } .party{font-size:10px;}}
			@media screen and (max-width: 1080px) {.nav-btn a {font-size: 12px;padding:0px;}}
			@media screen and (max-width: 760px) {.nav-btn a {font-size: 20px;padding:2px;}}
	</style>

<body  data-effect="fade" id="mypage" data-spy="scroll" data-target=".nav" data-offset="60">
	<a class="text-center ref" style="opacity:0.8;border-radius:20px;;padding:15px ;background-color:green; height: 50px;;position: fixed; bottom:30px;right:50px; z-index:1"
	href="#myPage" title="CLICK TO.. VOTE LINK..."><span style="color:white" class="glyphicon glyphicon-hand-up">&nbsp;Vote Button</span></a>


		<!--------- TITLE BAR --------->
		<div id="jssor_1" class="jumbotron text-center" style="position: relative ; margin: 0 auto; top: 0px; left: 0px; width:1300px; height:auto ; overflow: hidden; visibility: hidden;">
			<div data-u="slides" class="ttbf" style="cursor: default; position: fixed; top: 0px; left: 0px; width: 1300px; height: 600px;  overflow: hidden;">
				<div data-p="225.00">
					<img data-u="image" src="assets/img/red.jpg" />
				</div>
				<div data-p="225.00">
					<img data-u="image" src="assets/img/purple.jpg" />
				</div>
				<div data-p="225.00">
					<img data-u="image" src="assets/img/blue.jpg" />
				</div>
			</div>

			<div class="col-sm-12" style="padding-bottom:50px">
				<div class="col-sm-2">
					<img src="assets\img\logo.png" height="200px;" width="auto" style="">
				</div>
				<div class="col-sm-10">
					<h1 style="font-size:600%; color:white;" >BHARTIYA VOTER</h1>
					<p style="color:">PERFORM DIGITAL VOTING FOR DIGITAL INDIA</p>
				</div>
			</div>
		</div>
		<!------- Tile Bar End--------->

		<!--------- MARQUEE TAG --------->
		<MARQUEE onMouseOver="this.stop()" onMouseOut="this.start()" WIDTH=100% HEIGHT=20px>WE HAVE UPLOADED A <b>VIDEO</b> FOR YOUR REFERENCE. <a class="ref" href="#about" data-toggle="collapse" data-target="#video">CLICK HERE TO PROCEED</a></MARQUEE>
		<!------- Marquee tag End ------->

		<!--------- NAVAGATION BAR --------->
		<nav id="bar" class=" navbar-inverse"style="z-index:9999;" data-spy="affix" data-offset-top="300" >
		  <div class="container-fluid">
			<div class="navbar-header">
			  <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
			  </button>
			</div>

			<div class="collapse navbar-collapse" id="myNavbar">
				<ul class="nav navbar-nav navbar-left">
					<li class="active nav-btn" id="h-btn"><a href="#jssor_1"><span class="glyphicon glyphicon-home" style="color:white;">&nbsp;</span>HOME</a></li>
					<li class="nav-btn" ><a  class="nav-btn" href="#about" style="color:black;">ABOUT</a></li>
					<li class="nav-btn"><a  class="nav-btn" href="#services" style="color:black;">SERVICES</a></li>
					<!--<li><a href="#portfolio" style="color:black;">PORTFOLIO</a></li>-->
					<li class="nav-btn"><a  class="nav-btn" href="#party_details"style="color:black;">PARTY DETAILS</a></li>
					<li class="nav-btn"><a  class="nav-btn" href="#contact" style="color:black;">FEEDBACK</a></li>
					<li class="active nav-btn" id="h-btn"><a href="#myPage"><span class="glyphicon glyphicon-hand-up" style="color:white;">&nbsp;</span>Vote Button</a></li>
				 </ul>

				<ul class="nav navbar-nav navbar-right">
				  <li><a href=""  data-toggle="modal" data-target="#myModal" style="color:black;"><span class="glyphicon glyphicon-log-in"></span> Login</a></li>
				</ul>
			</div>
		  </div>
		</nav>
		<!--------- NAVAGATION BAR END --------->

		<!-------- MODAL BLOCK ------->
		<div id="myModal" class="modal fade" role="dialog">
		  <div class="modal-dialog" style="padding-top:10%">

			<!-- Modal content-->
			<div class="modal-content">
			  <div class="modal-header">
				<button type="button" class="close" data-dismiss="modal">&times;</button>
				<h4 class="modal-title">ADMIN LOGIN</h4>
			  </div>


				<div class="col-sm-12 slideanime "style="padding:20px;background-color:grey">
					  <div class="row" >
            <form action="process.php" method="POST">
						<div class="col-sm-12 form-group">
						  <input class="form-control"name="email_frm" placeholder="Admin ID" type="email" required>
						</div>
						<div class="col-sm-12 form-group">
						  <input class="form-control" name="pass_frm" placeholder="Password" type="password" required>
						</div>
					</div>
					  <div class="alert alert-danger"><strong>Warning!</strong> Only admin user are allowed to enter the database (3 time only).</div>
					</div>


			  <div class="modal-footer"  >
				  <button class="btn btn-login pull-left " style="margin-top:20px;" type="submit">Login</button>
				  <button class="btn btn-default" type="button" style="margin-top:20px;"  data-dismiss="modal">Close</button>
			  </div>
        </form>
			</div>

		  </div>
		</div>
		<!------- MODAL BLOCK End------>

		<!------- MAIN SECTION -------->
		<div id="myPage" class="header" style=" padding:0px ;overflow:hidden ">

			<!--------- FEEDBACK SLIDER --------->
			<div class="container-fluid" style="padding-top:40px;padding-bottom:20px;background-color:rgba(0, 0, 0, 0.6);color:white">
			 <center><h2>WHAT OUR USERS FEEDBACK's</h2'></center>
			  <div id="myCarousel" class="carousel slide text-center"  data-ride="carousel">
				<!-- Indicators -->
				<ol class="carousel-indicators" >
				  <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
				  <li data-target="#myCarousel" data-slide-to="1"></li>
				  <li data-target="#myCarousel" data-slide-to="2"></li>
				</ol>

				<!-- Wrapper for slides -->
				<div class="carousel-inner"  role="listbox">
				  <div class="item active" >
					<h4 style="font-size:15px;">“‎No people whose word for 'yesterday' is the same as their word for 'tomorrow' can be said to have a firm grip on the time.” <br>
          <span style="font-style:normal;"><b>- Salman Rushdie</b></span></h4>
				  </div>
				  <div class="item">
					<h4 style="font-size:15px;">"India is the cradle of the human race, the birthplace of human speech, the mother of history, the grandmother of legend, and the great grand mother of tradition. "<br>
          <span style="font-style:normal;"><b>- Mark Twain</b></span></h4>
				  </div>
				  <div class="item">
					<h4 style="font-size:15px;">"If there is one place on the face of earth where all the dreams of living men have found a home from the very earliest days when man began the dream of existence, it is India!"<br>
          <span style="font-style:normal;"><b>- Romaine Rolland</b></span></h4>
				  </div>
				</div>

				<!-- Left and right controls -->
				<a class="left carousel-control" href="#myCarousel" role="button" data-slide="prev">
				  <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
				  <span class="sr-only">Previous</span>
				</a>
				<a class="right carousel-control" href="#myCarousel" role="button" data-slide="next">
				  <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
				  <span class="sr-only">Next</span>
				</a>
			  </div>
			</div>
			<!-------- Feedback Slider End -------->

			<!--------- REGISTOR BUTTON ---------->
			<div style="padding:20px;">
				<center>
					<button data-toggle="tooltip" data-placement="bottom" title="CLICK TO PROCEED FOR VOTING" onclick="location.href='rigestration_page.php'"
					style="color:white;font-size:200%;margin-top:20px;padding:50px;background-color:rgba(0, 0, 0, 0.7);border-radius:50px;">
					<span style="color:white" class="glyphicon glyphicon-hand-up">&nbsp;</span>
					WELCOME TO THE WORLD OF DIGITAL VOTING

					</button>
				<h3 style="color:white">Click to vote &nbsp;<span style="color:white" class="glyphicon glyphicon-hand-up">&nbsp;</span></h3>
				</center>
			</div>
			<!------- Registor Button End -------->
		</div>
		<!--------- MAIN SECTION END ---------->

		<!-- Container (About Section) -->
		<div id="about" style="padding-top:20px;">
			<div id="" class="container col-sm-6" style="padding:30px;">
				<h2>About Our Voting Page</h2><br>
					<h4>Bhartiya Voter a online website for voting with confidentiality and security.</h4><br>
					<p><span class="glyphicon glyphicon-ok">&nbsp;</span>Here we are allow the citizens of india to vote with freedom and secuity.</p>
          <p><span class="glyphicon glyphicon-ok">&nbsp;</span>Voting Online using internet facilites. </p>
          <p><span class="glyphicon glyphicon-ok">&nbsp;</span>Fast result and reduced issues of counting and management. </p>
          <p><span class="glyphicon glyphicon-ok">&nbsp;</span>Efforts and rushness of the citizens will be reduced. </p>
          <p><span class="glyphicon glyphicon-ok">&nbsp;</span>New Technology new rising of the nation. </p>
          <p><span class="glyphicon glyphicon-ok">&nbsp;</span>And many more... </p>
      </div>
      <div class="col-sm-6" style="padding:30px;">
					<div id="video"  >
						<iframe width="100%" height="50%" src="https://www.youtube.com/embed/Q5EnvdWKlHw?autoplay=0"></iframe>
					</div>
			 </div>
		</div>
		<!-- Container (About Section) End-->

		<!-- Container (Misson Section) -->
		<div class="container-fluid bg-grey col-sm-12" style="padding:50px;">
		  <div class="row">
			<div class="col-sm-4" data-effect="fade" >
			  <center><img style="width:70%" src="assets/img/flag_ico.png" alt=""></center>
			</div>
			<div class="col-sm-8">
			  <h2>Our Values</h2><br>
			  <h4><strong>MISSION:</strong> Our mission is to reduce the complexity of voting, And make voting queus less by designing the better concept of online (Digital) voting for the citizens of India .</h4><br>
			  <p><strong>VISION:</strong> Our vision is to make india digital and give the poverty to indian citizens by allowing them to select their representative with all rights and freedom.
        Without Making hard efforts and duties of elections and voting arrangements and travel issues.
        </p>
			</div>
		  </div>
		</div>
		<!-- Container (Misson Section) End -->

		<!-- Container (Services Section) -->
		<div id="services" class="container-fluid text-center col-sm-12" style="padding:50px;" >
		  <h2>SERVICES</h2>
		  <h4>What we offer</h4>
		  <br>
		  <div class="row slideanim"data-effect="fade">
			<div class="col-sm-4">
			  <span class="glyphicon glyphicon-off logo-small"></span>
			  <h4>POWER</h4>
			  <p>Working without hard efforts..</p>
			</div>
			<div class="col-sm-4">
			  <span class="glyphicon glyphicon-heart logo-small"></span>
			  <h4>LOVE</h4>
			  <p>Equality for all age groups..</p>
			</div>
			<div class="col-sm-4">
			  <span class="glyphicon glyphicon-lock logo-small"></span>
			  <h4>JOB DONE</h4>
			  <p>Stay Confindent on whom you selected..</p>
			</div>
		  </div>
		  <br><br>
		  <div class="row slideanim">
			<div class="col-sm-4">
			  <span class="glyphicon glyphicon-leaf logo-small"></span>
			  <h4>GREEN</h4>
			  <p>No visting of camps, No waste..</p>
			</div>
			<div class="col-sm-4">
			  <span class="glyphicon glyphicon-certificate logo-small"></span>
			  <h4>CERTIFIED</h4>
			  <p>Your Identity will remaing hidden..</p>
			</div>
			<div class="col-sm-4">
			  <span class="glyphicon glyphicon-wrench logo-small"></span>
			  <h4 style="color:#303030;">HARD WORK</h4>
			  <p>Security that no one can break..</p>
			</div>
		  </div>
		</div>
		<!-- Container (Services Section) End-->

		<!-- Container (Party Details Section) -->
		<div id="party_details" class="container-fluid col-sm-12">
			<div class="text-center" style="background-color:db582f;padding:20px;color:white; margin:20px 0 20px 0;">
				<h1>SELECTED PARTY DETIALS</h1>
				<h4>Get the details of efforts contibuted by the parties.</h4>


					<!--------- MARQUEE TAG --------->
					<MARQUEE WIDTH=100% onMouseOver="this.stop()" onMouseOut="this.start()">
						<button class="center btn btn-info " style="margin:2px;font-size:15px;color:white" data-toggle="collapse" data-target="#tag1">How Many Parties Are there in India ? </button>
						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						<button class="center btn btn-info " style="margin:2px;font-size:15px;color:white" data-toggle="collapse" data-target="#tag2">What is meant by regional party ? </button>
						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						<button class="center btn btn-info " style="margin:2px;font-size:15px;color:white" data-toggle="collapse" data-target="#tag3">What is politics in India ??? </button>
						<br>

					</MARQUEE>

					<!------- Marquee tag End ------->

					<div id="tag1" class="collapse" style="background-color: rgba(150,0,0,0.5);border-radius:20px; ;padding:20px;">
						<p>The total number of State Parties is 52 and registered unrecognized parties, 1112. Now, the seven recognized national prties are the Listed Below</p>
					</div>

					<div id="tag2" class="collapse" style="background-color: rgba(150,0,0,0.5);border-radius:20px; ;padding:20px;">
						<p>Regional Parties are parties restricted to a particular state, And rooted in both regional aspiration and grivances.
						The support base of the party is limited to a perticular state because, it identiies itself with the region culture languages, etc</p>
					</div>

					<div id="tag3" class="collapse" style="background-color: rgba(150,0,0,0.5);border-radius:20px; ;padding:20px;">
						<p>The total number of State Parties is 52 and registered unrecognized parties, 1112. Now, the seven recognized national prties are the Listed Below</p>
					</div>


			</div>

			<div class="row slideanie">
				<div class="col-sm-6 col-xs-12">
					<div class="panel-head panel-default text-center">
						<div class="panel-heading">
						  <h1>National</h1>
						</div>

						<div class="panel-body" style="text-align:left ">
						  <p class="col-sm-12" style="padding:x;"><img class="col-sm-" src="assets/img/logo/AITC.png" height="30px" width="30px" alt="AITC">
                 <strong class="col-sm- party">(AITC)  All India Trinamool Congress.</strong>
                 <button class="btn btn-info col-sm- party pull-right" style="margin:2px" onClick=" location.href='https://en.wikipedia.org/wiki/All_India_Trinamool_Congress'" >Details</button>
              </p>


						  <p class="col-sm-12" style="padding:x;"><img class="col-sm-" src="assets/img/logo/BSP.png" height="30px" width="30px" alt="BSP">
                 <strong class="col-sm- party">(BSP)   Bhujan Samaj Party. </strong>
                <button class="btn btn-info col-sm- party pull-right" style="margin:2px;" onClick=" location.href='https://en.wikipedia.org/wiki/Bahujan_Samaj_Party'" >Details</button>
              </p>

						  <p class="col-sm-12" style="padding:x;"><img class="col-sm-" src="assets/img/logo/BJP.png" height="30px" width="30px" alt="BJP">
                 <strong class="col-sm- party">(BJP)   Bhartiya Janta Party. </strong>
                <button class="btn btn-info col-sm- party pull-right"style="margin:2px;" onClick=" location.href='https://en.wikipedia.org/wiki/Bharatiya_Janata_Party'" >Details</button>
              </p>

						  <p class="col-sm-12" style="padding:x;"><img class="col-sm-" src="assets/img/logo/CPI.png" height="30px" width="30px" alt="CPI">
                 <strong class="col-sm- party">(CPI)   Communist Party of India.</strong>
                <button class="btn btn-info col-sm- party pull-right" style="margin:2px;" onClick=" location.href='https://en.wikipedia.org/wiki/Communist_Party_of_India'" >Details</button>
              </p>

						  <p class="col-sm-12" style="padding:x;"><img class="col-sm-" src="assets/img/logo/CPIM.png" height="30px" width="30px" alt="CPIM">
                 <strong class="col-sm- party">(CPI-M) Communist Party of India (Marxist).</strong>
                <button class="btn btn-info col-sm- party pull-right"style="margin:2px;" onClick=" location.href='https://en.wikipedia.org/wiki/Communist_Party_of_India_(Marxist)'" >Details</button>
              </p>

					  	<p class="col-sm-12" style="padding:x;"><img class="col-sm-" src="assets/img/logo/INC.png" height="30px" width="30px" alt="INC">
                 <strong class="col-sm- party">(INC)   Indian National Congress.</strong>
                <button class="btn btn-info col-sm- party pull-right"style="margin:2px;" onClick=" location.href='https://en.wikipedia.org/wiki/Indian_National_Congress'" >Details</button>
              </p>

							<p class="col-sm-12" style="padding:x;"><img class="col-sm-" src="assets/img/logo/NCP.png" height="30px" width="30px" alt="NCP">
                 <strong class="col-sm- party">(NCP)   Nationalist Congress Party.</strong>
                  <button class="btn btn-info col-sm- party pull-right"style="margin:2px;" onClick=" location.href='https://en.wikipedia.org/wiki/Nationalist_Congress_Party'" >Details</button>
              </p>
						</div>

						<div class="panel-footer">
					<!--  <h3>$19</h3>
						  <h4>per month</h4>-->
						  <button class="btn btn-lg" data-toggle="collapse" data-target="#national_details">More Details...</button>

					<div id="national_details" class="collapse">
					The Following Parties Are been selected as the national parties of our country India.
					</div>

						</div>
					</div>
				</div>

				<div class="col-sm-6 col-xs-12">
					<div class="panel-head panel-default text-center">
						<div class="panel-heading">
							<h1>State / Regional</h1>
						</div>


						<div class="panel-body" style="text-align:left">
							<div class="dropdown" >
								<button class="btn btn-primary dropdown-toggle" type="button" data-toggle="dropdown">Select Your Region<span class="caret">&nbsp;</span></button>

								<ul class="dropdown-menu scrollable-menu text-center">
									<!--01-->				<li class="btn-p"><a class="btn" data-toggle="collapse" data-parent="#accordion" href="#Andaman">Andaman and Nicobar Islands</a></li>
									<!--02-->				<li class="btn-p"><a class="btn" data-toggle="collapse" data-parent="#accordion" href="#Andhra">Andhra Pradesh</a></li>
									<!--03-->				<li class="btn-p"><a class="btn" data-toggle="collapse" data-parent="#accordion" href="#Arunachal">Arunachal Pradesh</a></li>
									<!--04-->				<li class="btn-p"><a class="btn" data-toggle="collapse" data-parent="#accordion" href="#Assam">Assam</a></li>

								</ul>
							</div>

							<div class="panel-group" id="accordion" >
								<div class="panel" >
									<div id="collapse1" class="panel-collapse collapse in" >
										<center><h1>SELECT YOUR STATE</h1></center>
									</div>
								</div>

                <div class="panel"><div id="Andaman" class="panel-collapse collapse"><div style="text-align:left">
                <p> Current No Details</p>
   							</div></div></div>

								<div class="panel"><div id="Andhra" class="panel-collapse collapse"><div style="text-align:left">
											<p><strong class="col-sm-8">TDP - Telugu Desam Party</strong> <button class="btn btn-info col-sm-3" style="margin:2px;"  >Details</button></p>
											<p><strong class="col-sm-8">YSRCP - 	YSR Congress Party</strong>  <button class="btn btn-info col-sm-3" style="margin:2px;"  >Details</button></p>
								</div></div></div>

								<div class="panel"><div id="Arunachal" class="panel-collapse collapse"><div style="text-align:left">
											<p><strong class="col-sm-8">PPA - People''s Party of Arunachal</strong> <button class="btn btn-info col-sm-3" style="margin:2px;"  >Details</button></p>
								</div></div></div>

								<div class="panel"><div id="Assam" class="panel-collapse collapse"><div style="text-align:left">
											<p><strong class="col-sm-8">AIUDF - All India United Democratic Front</strong> <button class="btn btn-info col-sm-3" style="margin:2px;"  >Details</button></p>
	                    <p><strong class="col-sm-8">AGP - Asom Gana Parishad</strong> <button class="btn btn-info col-sm-3" style="margin:2px;"  >Details</button></p>
	                    <p><strong class="col-sm-8">BPF - Bodoland Peoples Front</strong> <button class="btn btn-info col-sm-3" style="margin:2px;"  >Details</button></p>
								</div></div></div>



							</div>
						</div>

						<div class="panel-footer">
							<button class="btn btn-lg">More Details ...</button>
						</div>
					</div>
				</div>
			</div>
		</div>
    <br>
		<!-- Container (Party Details Section) End -->

		<!-- Container (Feedback Section) -->
		<div id="contact" style="margin-top:20px;" class="container-fluid bg-grey col-sm-12">
		  <h2 class="text-center"><span class="glyphicon glyphicon-ok">&nbsp;</span>FEEDBACK</h2>
		  <div class="row">
			<div class="col-sm-5">
			  <p>Contact us and we''ll get back to you within 24 hours.</p>
			  <p><span class="glyphicon glyphicon-map-marker"></span> Mumbai, INDIA</p>
			  <p><span class="glyphicon glyphicon-phone"></span> +91 8655332519</p>
			  <p><span class="glyphicon glyphicon-envelope"></span> shaikh.danish4444@gmail.com</p>
			</div>
			<div class="col-sm-7 slideanim">

			<?php
				$connection = mysqli_connect('localhost','root','','bhartiya_voter');
				if(isset($_POST['name'])){ $named = $_POST['name']; }
				if(isset($_POST['email'])){ $emaild = $_POST['email']; }
				if(isset($_POST['comment'])){ $commentd = $_POST['comment']; }
				if (empty($_POST['name'])){}
				else{mysqli_query($connection,"insert into feedback values('$named','$emaild','$commentd');");}
			?>

			<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
			  <div class="row">
				<div class="col-sm-6 form-group">
				  <input class="form-control" id="name" name="name" placeholder="Name" type="text" required>
				</div>
				<div class="col-sm-6 form-group">
				  <input class="form-control" id="email" name="email" placeholder="Email" type="email" required>
				</div>
			  </div>
			  <textarea class="form-control" id="comments" name="comment" placeholder="Comment" rows="5"></textarea><br>
			  <div class="row">
				<div class="col-sm-12 form-group">
				  <button class="btn btn-default pull-right" type="submit">Send</button>
				</div>
			  </div>
			</form>
			</div>
		  </div>
		</div>
		<!-- Container (Feedback Section) Ends -->

		<!-- ********** CREDITS ********** -->
		<div id="" class="col-sm-12" data-effect="slide-bottom" style="height:150px;padding-top:20px;box-shadow: 0px 0px 15px black inset;">
			<div class="container ">
				<div class="row">
					<div class="centered text-center">
						<footer class="container-fluid text-center" >
						  <a href="#myPage" title="To Top">
							<span class="glyphicon glyphicon-chevron-up"></span>
						  </a>
						  <p>Voting Website Designed By <b>Danish Shaikh</b> </p>
              <a href="team_page.php">Developer Team</a>
              <br><br>
						  <p> Copyright <strong>@ V.E.S. Polytechnic</strong></p>
						</footer>
					</div>
				</div>
			</div><! --/container -->
		</div>
		<!--/C-->

		<script>
			function openNav() {
				document.getElementById("mySidenav").style.width = "50%";
				document.getElementById("main").style.marginLeft = "50%";
				document.body.style.backgroundColor = "rgba(0,0,0,0.4)";
			}

			function closeNav() {
				document.getElementById("mySidenav").style.width = "0";
				document.getElementById("main").style.marginLeft= "0";
				document.body.style.backgroundColor = "white";
			}
		</script>

		<script>

			$(document).ready(function(){
				$('[data-toggle="tooltip"]').tooltip();
			});
		</script>

		<!-- Bootstrap core JavaScript-->
		<!-- ================================================== -->
		<!-- Placed at the end of the document so the pages load faster -->
		<script src="assets/js/jquery.min.js"></script>
		<script src="assets/js/bootstrap.min.js"></script>
		<script src="assets/js/retina-1.1.0.js"></script>
		<script src="assets/js/jquery.unveilEffects.js"></script>
		<script type="text/javascript">jssor_1_slider_init();</script>
		<!-- #endregion Jssor Slider End -->

		<script>
			$(document).ready(function(){
			  // Add smooth scrolling to all links in navbar + footer link
			  $(".nav a,.ref, footer a[href='#myPage']").on('click', function(event) {
				// Make sure this.hash has a value before overriding default behavior
				if (this.hash !== "") {
				  // Prevent default anchor click behavior
				  event.preventDefault();

				  // Store hash
				  var hash = this.hash;

				  // Using jQuery's animate() method to add smooth page scroll
				  // The optional number (900) specifies the number of milliseconds it takes to scroll to the specified area
				  $('html, body').animate({
					scrollTop: $(hash).offset().top
				  }, 900, function(){

					// Add hash (#) to URL when done scrolling (default click behavior)
					window.location.hash = hash;
				  });
				} // End if
			  });
			  $(window).scroll(function() {
				$(".slideanim").each(function(){
				  var pos = $(this).offset().top;

				  var winTop = $(window).scrollTop();
					if (pos < winTop + 600) {
					  $(this).addClass("slide");
					}
				});
			  });

			})

		</script>

	</body>
</html>

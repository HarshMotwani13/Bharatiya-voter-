<!DOCTYPE PHP>
<?php

$vote_val = $_POST['radio'];

$click="1";


	$vc_db = mysqli_connect('localhost','root','','vote_collect');
  mysqli_query($vc_db,"insert into $vote_val values('','$click')");
  mysqli_query($vc_db,"insert into aa_citizen_voted values('','$click')");
//      echo "<script type='text/javascript'>alert('Thank You For Voting $vote_val');</script>";
  //    echo "<script type='text/javascript'>window.location='index.php';</script>";

?>
 <html>

	<head>
		<title>BHARTIYA VOTER</title>

		<!-- browser info -->
		<meta charset="UTF-8">
		<meta name="description" content="Free Web tutorials">
		<meta name="keywords" content="HTML,CSS,XML,JavaScript">
		<meta name="author" content="DANISH SHAIKH">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">

		<!-- core bootstrap -->
		<link rel="stylesheet" href="assets/css/bootstrap.min.css">

		<!-- Custom style -->
		<link href="assets/css/mystyle.css" rel="stylesheet">


	</head>

	<style>
			body {background: url(assets/img/c-slide-3.jpg) no-repeat fixed 100% 100%;background-size:100% 100%;background-position:center;}

			input[type=number], select {width: 100%;padding: 12px 20px;margin: 8px 0;display: inline-block;border: 1px solid #ccc;border-radius: 4px;box-sizing: border-box;}

			input[type=email], select {width: 100%;padding: 12px 20px;margin: 8px 0;display: inline-block;border: 1px solid #ccc;border-radius: 4px;box-sizing: border-box;}

			input[type=submit] {width: 100%;background-color: #4CAF50;color: white;padding: 14px 20px;margin: 8px 0;border: none;border-radius: 4px;cursor: pointer;}
			input[type=submit]:hover {background-color: #45a049;}

			.inp{width: 100%;background-color: #4CAF50;color: white;padding: 14px 20px;margin: 8px 0;border: none;border-radius: 4px;cursor: pointer;}
			.inp:hover {background-color: #45a049;}

			.box {border-radius: 5px;background-color: #f2f2f2;padding: 20px;}

			.btn-2 { background:orange;}
			.btn-2:hover { backgroung:green;}
	</style>

	<body>

		<!--------- TITLE BAR --------->
		<button class="inp" style="margin:0px;font-size:20px;"  onclick="location.href='index.php'"><span class="glyphicon glyphicon-home" style="color:white;">&nbsp;</span>HOME</button>
		<div  class="jumbotron text-center" style="margin:0px;background:black;color:white;opacity:0.7;">
		<h1>THANK YOU</h1>
		</div>
		<!--------- TITLE BAR End --------->

		<div class="text-center" style="height:400px;padding-top:100px;">
		<h1>Your Vote Is Been Submited Please Click On Home Button&nbsp; <span class="glyphicon glyphicon-home">&nbsp;</span></h1>
    <?php echo "The voter has successfully voted to ".$vote_val;
?>
		</div>


		<!-- ********** CREDITS ********** -->
		<div id="" class="" data-effect="slide-bottom" style="position:0px ;background-color:white;width:100%;height:150px;padding-top:20px;box-shadow: 0px 0px 15px black inset;">
			<div class="container">
				<div class="row">
					<div class="centered text-center">
						<footer class="container-fluid text-center" >

						  <p>Voting Website Designed By <b>Danish Shaikh</b> </p>
              <a href="team_page.php">Developer Team</a>
              <br><br>
						  <p> Copyright <strong>@ V.E.S. Polytechnic</strong></p>
						</footer>
					</div>
				</div>
			</div><! --/container -->

	</body>
</html>

<?php
	$db_name="bhartiya_voter"; // name of the  database
	$mysql_user="root"; // name of the user
	$mysql_pass=""; // password of the database
	$server_name="localhost"; // name of the server
	$conn = mysqli_connect($server_name,$mysql_user,$mysql_pass,$db_name);
?>
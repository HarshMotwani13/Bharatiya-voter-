<?php
session_start();
//checking second page values for empty,If it finds any blank field then redirected to second page
$party1 = "(AITC)  All India Trinamool Congress.";
$party1_sym = "AITC";

$party2 = "(BSP)   Bhujan Samaj Party.";
$party2_sym = "BSP";

$party3 = "(BJP)   Bhartiya Janta Party.";
$party3_sym = "BJP";

$party4 = "(CPI)   Communist Party of India.";
$party4_sym = "CPI";

$party5 = "(CPI-M) Communist Party of India (Marxist).";
$party5_sym = "CPIM";

$party6 = "(INC)   Indian National Congress.";
$party6_sym = "INC";

$party7 = "(NCP)   Nationalist Congress Party.";
$party7_sym = "NCP";

if (empty($_POST['Email']) && empty($_POST['PNumber'])){
				$message = "At Least One Field Is Mandatory (Required)";
				echo "<script type='text/javascript'>alert('$message');</script>";
				echo "<script type='text/javascript'>window.location='rigestration_page.php';</script>";


}


else {
			//fetching all values posted from second page and storing it in variable
			foreach ($_POST as $key => $value) { $_SESSION['post'][$key] = $value; }


      $seed = str_split('ABCDEFGHIJKLMNOPQRSTUVWXYZ'.'0123456789'); // and any other characters
      shuffle($seed); // probably optional since array_is randomized; this may be redundant
      $rand = '';
      foreach (array_rand($seed, 14) as $k) $rand .= $seed[$k];


      //$rand = substr(md5(microtime()),rand(0,26),14);


			extract($_SESSION['post']);

				$bv_db = mysqli_connect('localhost','root','','bhartiya_voter');
				mysqli_query($bv_db,"insert into rgst values('','$FName','$MName','$LName','$bday','$gender','$UID');");
				mysqli_query($bv_db,"insert into vefi values('$Email','$PNumber','$UID');");


	}


?>
<html>
	<head>
		<title>BHARTIYA VOTER</title>

		<!-- browser info -->
		<meta charset="UTF-8">
		<meta name="description" content="Free Web tutorials">
		<meta name="keywords" content="HTML,CSS,XML,JavaScript">
		<meta name="author" content="DANISH SHAIKH">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">

		<!-- core bootstrap -->
		<link rel="stylesheet" href="assets/css/bootstrap.min.css">
		<link rel="stylesheet" href="assets/css/w3.css">
		<link rel="stylesheet" href="assets/css/radiostyle.css">
		<!-- Custom style -->
		<link href="assets/css/style.css" rel="stylesheet">

	</head>

	<style>


			body {background: url(assets/img/c-slide-3.jpg) no-repeat fixed 100% 100%;background-size:100% 100%;background-position:center;}

			input[type=number], select {width: 100%;padding: 12px 20px;margin: 8px 0;display: inline-block;border: 1px solid #ccc;border-radius: 4px;box-sizing: border-box;}


			input[type=email], select {width: 100%;padding: 12px 20px;margin: 8px 0;display: inline-block;border: 1px solid #ccc;border-radius: 4px;box-sizing: border-box;}

			input[type=submit] {width: 100%;background-color: #4CAF50;color: white;padding: 14px 20px;margin: 8px 0;border: none;border-radius: 4px;cursor: pointer;}
			input[type=submit]:hover {background-color: #45a049;}

			.inp{width: 100%;background-color: #4CAF50;color: white;padding: 14px 20px;margin: 8px 0;border: none;border-radius: 4px;cursor: pointer;}
			.inp:hover {background-color: #45a049;}

			.box {border-radius: 5px;background-color: #f2f2f2;padding: 20px;}

			.btn-2 { background:orange;}
			.btn-2:hover { backgroung:green;}


	</style>

	<body>
		<!--------- TITLE BAR --------->
		<button class="inp" style="margin:0px;font-size:20px;"  onclick="location.href='index.php'"><span class="glyphicon glyphicon-home" style="color:white;">&nbsp;</span>HOME</button>
		<div  class="jumbotron text-center" style="margin:0px;background:black;color:white;opacity:0.7;">
		<h1>VALIDATION</h1>
		</div>
		<!--------- TITLE BAR End --------->

		<!--------- MAIN PAGE --------->
           <form action="ok.php" method="post">

	<div  id="" style="padding:3%; box-shadow: 0px 0px 15px black inset;  ">
			<div id="main" class="" style="">
				<div class="col-sm-6" style="padding:20px;">
					<div class="container box col-sm-12" style="opacity:0.9" >
						<div style="padding:10px;background:;height:;" >
							<div class="col-sm-12">
							<div style="background:"><b style="font-size:30px;">VOTER DETAILS :</b></div>

								<div class="col-sm-3">
								<img src="assets/img/logo.png" alt="Smiley face" height="" width="100%">
								</div>
								<div class="col-sm-9"><?php extract($_SESSION['post']); ?>
									<div class="col-sm-12" style="margin-top:10px;"><strong>Full Name :</strong><?Php echo " ",$FName," ",$MName," ",$LName; ?> </div>
									<div class="col-sm-12" style="margin-top:10px;"><strong>DOB :</strong> <?Php echo " ",$bday ?> </div>
									<div class="col-sm-12" style="margin-top:10px;"><strong>Gender :</strong><?Php echo " ",$gender; ?> </div>
									<div class="col-sm-12" style="margin-top:10px;"><strong>Documents Accepted :</strong> </div>
                    <br>
                    <div class="col-sm-6">

                        <?Php echo "UID : ", $UID; ?>
                        <br>
                        <?Php echo "PAN : ", $PAN; ?>

                    </div>

                    <div class="col-sm-6">

                    </div>
                </div>
							</div>
						</div>
					</div>
					<br>

					<div class="container box col-sm-12" style="opacity:0.9;margin-top:20px;" >
						<div style="padding:10px;background:;height:;" >
							<b style="font-size:30px;">VOTER ID NUMBER:</b> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b style="font-size:20px"><?php echo $rand;  ?></b>

						</div>
					</div>

					<div class="container box col-sm-12" style="opacity:0.9;margin-top:20px;" >
						<div style="padding:10px;background:;height:;" >
							<b style="font-size:30px;">Enter The OTP:</b><?php
              if (empty($_POST['Email'])){$dis = $PNumber;}
               if (empty($_POST['PNumber'])){$dis = $Email;}

                echo "   <strong style='font-size:20px;'><i> Sended On - </i></strong> ". $dis;
               ?>
							<input type="text" id="OTP" style="padding:10px;;width:100%" placeholder="#######" required>

						</div>
					</div>

					<div class="container box col-sm-12" style="opacity:0.9;margin-top:20px;" >
						<div style="padding:10px;background:;height:;" >
							<b style="font-size:30px;">OPTIONS:</b>
							<p style="font-size:15px;">Select Yes If Your Want To Recive The Confirmation OTP</p>
							<select style=""><option>YES</option><option>NO</option></select>

						</div>
					</div>
				</div>



				<div class="col-sm-6 text-center" style="padding:20px;">
					<div class="container box col-sm-12" style="color:white;background-color:rgba(0,0,0,0.7)" >
						<div style="padding:10px;;" >
							<p><b style="font-size:30px;">BALLAT OF YOUR REGION</b></p>
							<h4>Select The party You Want To Vote</h4>
								<div class="container col-sm-12" style="text-align:left;margin:20px 0 20px 0;border-radius:20px;background-color:white;height:;padding:5%;" >

                  <div class="col-sm-12">
                     <img class="col-sm-2" style="margin-top:10px;" src="assets/img/logo/AITC.png" height="30px" width="30px" alt="AITC">
                     <label class="control control--radio col-sm-10" style="padding-left:50px;" ><?php echo $party1; ?>
                       <input type="radio" name="radio" value="<?php echo $party1_sym; ?>"/>
                       <div class="control__indicator"></div>
                   </div>
                     </label>

                  <div class="col-sm-12">
                     <img class="col-sm-2" style="margin-top:10px;" src="assets/img/logo/BSP.png" height="30px" width="30px" alt="BSP">
                     <label class="control control--radio col-sm-10" style="padding-left:50px;"><?php echo $party2; ?>
                       <input type="radio" name="radio " value="<?php echo $party2_sym; ?>"/>
                       <div class="control__indicator"></div>
                     </label>
                  </div>

                  <div class="col-sm-12">
                     <img class="col-sm-2" style="margin-top:10px;" src="assets/img/logo/BJP.png" height="30px" width="30px" alt="BJP">
                     <label class="control control--radio col-sm-10" style="padding-left:50px;"><?php echo $party3; ?>
                       <input type="radio" name="radio" value="<?php echo $party3_sym; ?>"/>
                       <div class="control__indicator"></div>
                     </label>
                  </div>

                  <div class="col-sm-12">
                     <img class="col-sm-2" style="margin-top:10px;" src="assets/img/logo/CPI.png" height="30px" width="30px" alt="CPI">
                     <label class="control control--radio col-sm-10" style="padding-left:50px;"><?php echo $party4; ?>
                       <input type="radio" name="radio" value="<?php echo $party4_sym; ?>"/>
                       <div class="control__indicator"></div>
                     </label>
                  </div>

                  <div class="col-sm-12">
                     <img class="col-sm-2" style="margin-top:10px;" src="assets/img/logo/CPIM.png" height="30px" width="30px" alt="CPIM">
                     <label class="control control--radio col-sm-10" style="padding-left:50px;"><?php echo $party5; ?>
                       <input type="radio" name="radio" value="<?php echo $party5_sym; ?>"/>
                       <div class="control__indicator"></div>
                     </label>
                  </div>

                  <div class="col-sm-12">
                     <img class="col-sm-2" style="margin-top:10px;" src="assets/img/logo/INC.png" height="30px" width="30px" alt="INC">
                     <label class="control control--radio col-sm-10" style="padding-left:50px;"><?php echo $party6; ?>
                       <input type="radio" name="radio" value="<?php echo $party6_sym; ?>"/>
                       <div class="control__indicator"></div>
                     </label>
                  </div>

                  <div class="col-sm-12">
                     <img class="col-sm-2" style="margin-top:10px;" src="assets/img/logo/NCP.png" height="30px" width="30px" alt="NCP">
                     <label class="control control--radio col-sm-10" style="padding-left:50px;"><?php echo $party7; ?>
                       <input type="radio" name="radio" value="<?php echo $party7_sym; ?>"/>
                       <div class="control__indicator"></div>
                     </label>
                  </div>
<!--
                      <h1>Radio buttons</h1>

                      <label class="control control--radio">Disabled
                        <input type="radio" name="radio2" disabled="disabled"/>
                        <div class="control__indicator"></div>
                      </label>
                      <label class="control control--radio">Disabled & checked
                        <input type="radio" name="radio2" disabled="disabled" checked="checked"/>
                        <div class="control__indicator"></div>
                       </label>
-->

								</div>
						</div>
					</div>
				</div>

		</div>

					<div class="container" style="width:100%;">
						<h3><input type="submit" value="Click To Submit" style="opacity:0.8;background:orange;" class="w3-btn w3-green w3-text-shadow" ></h3>
					</div>
				</div>
</form>
		<!-- ********** CREDITS ********** -->
		<div id="" class="" data-effect="slide-bottom" style="position:0px ;background-color:white;width:100%;height:150px;padding-top:20px;box-shadow: 0px 0px 15px black inset;">
			<div class="container">
				<div class="row">
					<div class="centered text-center">
						<footer class="container-fluid text-center" >

						  <p>Voting Website Designed By <b>Danish Shaikh</b> </p>
              <a href="team_page.php">Developer Team</a>
              <br><br>
						  <p> Copyright <strong>@ V.E.S. Polytechnic</strong></p>
						</footer>
					</div>
				</div>
			</div><! --/container -->
</body>
</html>

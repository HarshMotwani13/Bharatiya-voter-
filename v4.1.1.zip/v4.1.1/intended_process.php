
<?php
if (!preg_match("/^[0-9]{12}$/", $_POST['UID'])){

       $message = "Adhar UID number is Not Valid (Must be 12 digit)";
       echo "<script type='text/javascript'>alert('$message');</script>";
       echo "<script type='text/javascript'>window.location='rigestration_page.php';</script>";

           }

     else{
 $FName_var = $_POST['FName'];
 $UID_var  = $_POST['UID'];
 $PAN_var = $_POST['PAN'];
 $gender_var = $_POST['gender'];
 $bday_var = $_POST['bday'];

$region_num = $_POST['region'];
$switch_num = $region_num;
switch ($switch_num) {
    case "400071":
        $region_var = 'chembur';
        //echo "<script type='text/javascript'>alert('Your Data Is submited');</script>";
        break;
    case "400070":
        $region_var = 'kurla';
        //echo "<script type='text/javascript'>alert('Your Data Is submited');</script>";
        break;
    default:
        echo "<script type='text/javascript'>alert('Wrong Region Details');</script>";
}



	$gov_db = mysqli_connect('localhost','root','','gov_db');

mysqli_query($gov_db,"insert into $region_var values('','$FName_var','$UID_var','$PAN_var','$gender_var','$bday_var')");
mysqli_query($gov_db,"insert into count_tb values('','1')");

 // $db = mysqli_connect('localhost','root','','gov_db');
 // mysqli_query($db,"insert into 400070 values('$FName_var','$UID_var','$PAN_var','$gender_var','$bday_var')");



echo "<script type='text/javascript'>window.location='intender.php';</script>";


}
 ?>

<?php
$party1 = "(AITC)  All India Trinamool Congress.";
$party1_sym = "AITC";

$party2 = "(BSP)   Bhujan Samaj Party.";
$party2_sym = "BSP";

$party3 = "(BJP)   Bhartiya Janta Party.";
$party3_sym = "BJP";

$party4 = "(CPI)   Communist Party of India.";
$party4_sym = "CPI";

$party5 = "(CPI-M) Communist Party of India (Marxist).";
$party5_sym = "CPIM";

$party6 = "(INC)   Indian National Congress.";
$party6_sym = "INC";

$party7 = "(NCP)   Nationalist Congress Party.";
$party7_sym = "NCP";

$db2 = mysqli_connect('localhost','root','','bhartiya_voter') or die('Error connecting to MySQL server.');

$db = mysqli_connect('localhost','root','','vote_collect') or die('Error connecting to MySQL server.');

$gov_db = mysqli_connect('localhost','root','','gov_db');
if ($result = mysqli_query($db, "SELECT * FROM $party1_sym")) {$row_cnt1 = mysqli_num_rows($result);}

if ($result = mysqli_query($db, "SELECT * FROM $party2_sym")) {$row_cnt2 = mysqli_num_rows($result);}

if ($result = mysqli_query($db, "SELECT * FROM $party3_sym")) {$row_cnt3 = mysqli_num_rows($result);}

if ($result = mysqli_query($db, "SELECT * FROM $party4_sym")) {$row_cnt4 = mysqli_num_rows($result);}

if ($result = mysqli_query($db, "SELECT * FROM $party5_sym")) {$row_cnt5 = mysqli_num_rows($result);}

if ($result = mysqli_query($db, "SELECT * FROM $party6_sym")) {$row_cnt6 = mysqli_num_rows($result);}

if ($result = mysqli_query($db, "SELECT * FROM $party7_sym")) {$row_cnt7 = mysqli_num_rows($result);}

if ($result = mysqli_query($db, "SELECT * FROM aa_citizen_voted")) {$row_aal = mysqli_num_rows($result);}

if ($result = mysqli_query($gov_db, "SELECT * FROM count_tb")) {$row_test = mysqli_num_rows($result);}

mysqli_close($db);
//    mysqli_free_result($result);
?>

<html>
<head>
  <title>BHARTIYA VOTER</title>

  <!-- browser info -->
  <meta charset="UTF-8">
  <meta name="description" content="Free Web tutorials">
  <meta name="keywords" content="HTML,CSS,XML,JavaScript">
  <meta name="author" content="DANISH SHAIKH">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">


  <link href="assets/css/bootstrap.css" rel="stylesheet">

  <!-- core bootstrap -->
  <link rel="stylesheet" href="assets/css/bootstrap.min.css">
  <link rel="stylesheet" href="assets/css/w3.css">
  <!-- Custom style -->
  <link href="assets/css/mystyle.css" rel="stylesheet">
</head>
<style>
    body {background: url(assets/img/c-slide-3.jpg) no-repeat fixed 100% 100%;background-size:100% 100%;background-position:center;}

    .inp{width: 100%;background-color: #4CAF50;color: white;padding: 14px 20px;margin: 8px 0;border: none;border-radius: 4px;cursor: pointer;}
    .inp:hover {background-color: #45a049;}
h1 {font-size: 40px;}
</style>

<body>

  <!--------- TITLE BAR --------->
  <button class="inp" style="margin:0px;font-size:20px;"  onclick="location.href='index.php'"><span class="glyphicon glyphicon-home" style="color:white;">&nbsp;</span>HOME</button>
  <div  class="jumbotron text-center" style="margin:0px;background-color:rgba(0,0,0, 0.7);color:white;">
  <h1>DEVELOPER TEAM</h1>
  </div>
  <!--------- TITLE BAR End--------->

<div style="padding:30px; ">
 <div class="container-fluid" style="background-color:white;padding:40px;border-radius:20px;" >
<button class="btn btn-default btn-lg" onclick="location.href='intender.php'" >Add Citizens</button>&nbsp;&nbsp;&nbsp;&nbsp;<i>Please Click To Add More Citizens</i>
<br>
---------------------------------------------------------------------------------------
<br>
    <?php


    echo $party1 .'<br>' . ' Has collected '. $row_cnt1. '  votes'. '<br>'. '<br>';
    echo $party2 .'<br>' . ' Has collected '. $row_cnt2. '  votes' . '<br>'. '<br>';
    echo $party3 .'<br>' . ' Has collected '. $row_cnt3. '  votes'. '<br>'. '<br>';
    echo $party4 .'<br>' . ' Has collected '. $row_cnt4. '  votes' . '<br>'. '<br>';
    echo $party5 .'<br>' . ' Has collected '. $row_cnt5. '  votes'. '<br>'. '<br>';
    echo $party6 .'<br>' . ' Has collected '. $row_cnt6. '  votes' . '<br>'. '<br>';
    echo $party7 .'<br>' . ' Has collected '. $row_cnt7. '  votes'. '<br>';
    echo "---------------------------------------------------------------------<br>";
    echo '<strong>Total Number of Citizens Voted are </strong>'.$row_aal . '<strong> out of </strong>' . $row_test .' <strong>registered.</strong>';
    //echo '<strong>Total Number of Citizens Present are </strong>'.$row_test;


     ?>


      <a class="btn" data-toggle="collapse" data-target="#demo">&nbsp;&nbsp;&nbsp;</a>

      <div id="demo" class="collapse">
       <form action="truncate.php" method="POST";
         <h3><input type="submit" value="Do Your Want To Continue ??" style="opacity:0.8;background:orange;" class="w3-btn w3-red w3-text-shadow" ></h3>
       </form>
      </div>


  </div>
</div>
<!-- ********** CREDITS ********** -->
<div id="" class="" data-effect="slide-bottom" style="position:0px ;background-color:white;width:100%;height:150px;padding-top:20px;box-shadow: 0px 0px 15px black inset;position: ;bottom: 0px;">
  <div class="container">
    <div class="row">
      <div class="centered text-center">
        <footer class="container-fluid text-center" >

          <p>Voting Website Designed By <b>Danish Shaikh</b> </p>
          <a href="team_page.php">Developer Team</a>
          <br><br>
          <p> Copyright <strong>@ V.E.S. Polytechnic</strong></p>
        </footer>
      </div>
    </div>
  </div><! --/container -->
</div>
<!-- Bootstrap core JavaScript-->
<!-- ================================================== -->
<!-- Placed at the end of the document so the pages load faster -->
<script src="assets/js/jquery.min.js"></script>
<script src="assets/js/bootstrap.min.js"></script>

</body>
</html>

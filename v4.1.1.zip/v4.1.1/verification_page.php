<!DOCTYPE PHP>
<?php
$region_num = $_POST['region'];
$switch_num = $region_num;
switch ($switch_num) {
    case "400071":
        $region_var = 'chembur';
        //echo "<script type='text/javascript'>alert('Your Data Is submited');</script>";
        break;
    case "400070":
        $region_var = 'kurla';

        break;
    default:
        echo "<script type='text/javascript'>alert('Wrong Region Details');</script>";
}
?>

<?php
session_start();
$db = mysqli_connect('localhost','root','','bhartiya_voter') or die('Error connecting to MySQL server.');
$gov_db = mysqli_connect('localhost','root','','gov_db') or die('Error connecting to MySQL server.');
 if (!preg_match("/^[0-9]{12}$/", $_POST['UID'])){

				$message = "Adhar UID number is Not Valid (Must be 12 digit)";
				echo "<script type='text/javascript'>alert('$message');</script>";
				echo "<script type='text/javascript'>window.location='rigestration_page.php';</script>";

            }

			else{
        $UID_var = $_POST['UID'];
        $PAN_var = $_POST['PAN'];
        $gender_var = $_POST['gender'];
        $bday_var = $_POST['bday'];

        $result = mysqli_query($gov_db,"SELECT * FROM $region_var where UID = '$UID_var'");
        $row = mysqli_fetch_array($result);
        if($row["UID"]==$UID_var && $row['PAN']==$PAN_var && $row['gender']==$gender_var && $row['bday']==$bday_var)
          {
          //  echo "<script type='text/javascript'>alert('Great! Your are a registered citizen of INDIA');</script>";
             $query = "SELECT * FROM rgst where UID = '$UID_var'";
             $result = mysqli_query($db, $query) or die('Error querying database.');
              $row2 = mysqli_fetch_array($result);

            if($row2['UID']==$UID_var)
            {
             echo "<script type='text/javascript'>alert('Thank You! But You Have All Ready Voted');</script>";
             echo "<script type='text/javascript'>window.location='rigestration_page.php';</script>";
            }
            else
            foreach ($_POST as $key => $value) {$_SESSION['post'][$key] = $value;}
          }
          else { echo "<script type='text/javascript'>alert('Wrong Details! Not applicable for voting');</script>";
           echo "<script type='text/javascript'>window.location='rigestration_page.php';</script>";
          }



					//extract($_SESSION['post']);

					//$connection = mysqli_connect('localhost','root','','bhartiya_voter');
					//mysqli_query($connection,"insert into rgst values('$FName','$MName','$LName','$date','$month','$year','$gender','$UID');");

				}

?>


<html>
	<head>
		<title>BHARTIYA VOTER</title>

		<!-- browser info -->
		<meta charset="UTF-8">
		<meta name="description" content="Free Web tutorials">
		<meta name="keywords" content="HTML,CSS,XML,JavaScript">
		<meta name="author" content="DANISH SHAIKH">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">

		<!-- core bootstrap -->
		<link rel="stylesheet" href="assets/css/bootstrap.min.css">
		<link rel="stylesheet" href="assets/css/w3.css">
		<!-- Custom style -->
		<link href="assets/css/mystyle.css" rel="stylesheet">


	</head>

	<style>
			body {background: url(assets/img/c-slide-3.jpg) no-repeat fixed 100% 100%;background-size:100% 100%;background-position:center;}

			input[type=number], select {width: 100%;padding: 12px 20px;margin: 8px 0;display: inline-block;border: 1px solid #ccc;border-radius: 4px;box-sizing: border-box;}

			input[type=email], select {width: 100%;padding: 12px 20px;margin: 8px 0;display: inline-block;border: 1px solid #ccc;border-radius: 4px;box-sizing: border-box;}

			input[type=submit] {width: 100%;background-color: #4CAF50;color: white;padding: 14px 20px;margin: 8px 0;border: none;border-radius: 4px;cursor: pointer;}
			input[type=submit]:hover {background-color: #45a049;}

			.inp{width: 100%;background-color: #4CAF50;color: white;padding: 14px 20px;margin: 8px 0;border: none;border-radius: 4px;cursor: pointer;}
			.inp:hover {background-color: #45a049;}

			.box {border-radius: 5px;background-color: #f2f2f2;padding: 20px;}

			.btn-2 { background:orange;}
			.btn-2:hover { backgroung:green;}
	</style>

	<body>

		<!--------- TITLE BAR --------->
		<button class="inp" style="margin:0px;font-size:20px;"  onclick="location.href='index.php'"><span class="glyphicon glyphicon-home" style="color:white;">&nbsp;</span>HOME</button>
		<div  class="jumbotron text-center" style="margin:0px;background:black;color:white;opacity:0.7;">
		<h1>VERIFICATION</h1>
		</div>
		<!--------- TITLE BAR End --------->
		  <span id="error">
				<?php
				//To show error of page 2S
				if (!empty($_SESSION['error_page2'])) {
					echo $_SESSION['error_page2'];
					unset($_SESSION['error_page2']);
				}
				?>
            </span>
		<!--------- MAIN PAGE --------->
	<form action="validation_page.php" method="post">
		<div style="padding:3%; box-shadow: 0px 0px 15px black inset;  ">
			<div id="main" >
				<div class="container box" style="opacity:0.9">
          <div class="alert alert-danger">
            <strong>Warning!</strong> At least Entering Details in One field is Compulsary.
          </div>

					<div style=";background:;height:" >
						<div class="col-sm-12" style="background-color:rgba(100,100,100,0.2);border-radius:10px;padding:10px;">
  						<div style="padding:10px;"><b style="font-size:30px;">OTP</b></div>

                <div class="col-sm-4 text-center" style="padding:20px;">
                  <button class="btn-primary btn" style="width:100%" data-toggle="collapse" data-parent="#accordion" href="#collapse1">Email Address</button>
                  <div style="margin:5px;"><h3>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;OR&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</h3></div>
                  <button class="btn-primary btn" style="width:100%" data-toggle="collapse" data-parent="#accordion" href="#collapse2">Contact Number</button>
                </div>

              <div class="col-sm-8 panel-group"  id="accordion">
                <div class="panel panel-default">
                  <div id="collapse1"  class="panel-collapse collapse in">
                    <div class="panel-body" ><div class="col-sm-12" >Enter Your E-mail Address<input type="email" name="Email" autocomplete="on" placeholder="E-mail Address"></div></div>
                  </div>

                  <div id="collapse2" class="panel-collapse collapse">
                    <div class="panel-body"><div class="col-sm-12">Enter Your Mobile Number<input type="number" name="PNumber" placeholder="Mobile number" ></div></div>
                  </div>

                </div>
              </div>
						</div>
          </div>

				</div>
			</div>

			<div class="container" style="width:100%;">
				<h3><input type="submit" value="Click To Submit" style="opacity:0.8;background:orange;" class="w3-btn w3-green w3-text-shadow" onclick="location.href='validation_page.php'"></h3>
			</div>
		</div>
	</form>
		<!--------- MAIN PAGE End--------->

		<!-- ********** CREDITS ********** -->
		<div id="" class="" data-effect="slide-bottom" style="position:0px ;background-color:white;width:100%;height:150px;padding-top:20px;box-shadow: 0px 0px 15px black inset;">
			<div class="container">
				<div class="row">
					<div class="centered text-center">
						<footer class="container-fluid text-center" >

						  <p>Voting Website Designed By <b>Danish Shaikh</b> </p>
              <a href="team_page.php">Developer Team</a>
              <br><br>
						  <p> Copyright <strong>@ V.E.S. Polytechnic</strong></p>
						</footer>
					</div>
				</div>
			</div><! --/container -->
	<!-- Bootstrap core JavaScript-->
  <!-- ================================================== -->
  <!-- Placed at the end of the document so the pages load faster -->
  <script src="assets/js/jquery.min.js"></script>
  <script src="assets/js/bootstrap.min.js"></script>
	</body>
</html>

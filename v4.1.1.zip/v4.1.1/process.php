<?php
$db = mysqli_connect('localhost','root','','bhartiya_voter') or die('Error connecting to MySQL server.');

$email_var = $_POST['email_frm'];
$pass_var = $_POST['pass_frm'];

$query = "SELECT * FROM adlog where email = '$email_var'";

$result = mysqli_query($db, $query) or die('Error querying database.');

$row = mysqli_fetch_array($result);

if($row["email"]==$email_var && $row["pass"]==$pass_var)
{
$link1 = "<script>window.open('http://localhost/phpmyadmin/db_structure.php?server=1&db=bhartiya_voter', 'width=710,height=555,left=160,top=170')</script>";
$link2 = "<script type='text/javascript'>window.location='vote_check.php';</script>";

 echo $link1. $link2 ;
}
else {
  echo "<script type='text/javascript'>alert('Not applicable for login');</script>";
  echo "<script type='text/javascript'>window.location='index.php';</script>";
}

mysqli_close($db);
?>
